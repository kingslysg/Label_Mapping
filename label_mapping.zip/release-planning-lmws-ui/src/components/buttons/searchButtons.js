import React, { useState } from 'react';
import { Row, Col, Button, Tooltip } from 'antd';
import * as Constants from '../util/constants';


export default function SearchButtons({ disableRest, disableSearch, onResetClick, onSearchclick, showSave=false }) {

  const handleResetClick = () => {
    onResetClick();
  };

  const handleSearchClick = () => {
    onSearchclick();
  };

  return (
    <div>
      <Row>
        <Col className="search-reset-col">
          <Button
            disabled={disableRest}
            className='defaultButtonStyle'
            onClick={handleResetClick}
          >
            {Constants.BUTTON_RESET}
          </Button>
        </Col>
        <Col>
          <Tooltip title={disableSearch ? Constants.BUTTON_SEARCH_TOOLTIP : ''} >
            <Button
              disabled={disableSearch}
              className='selectedButtonStyle'
              type="primary"
              onClick={handleSearchClick}
            >
              {showSave === false ? Constants.BUTTON_SEARCH : Constants.BUTTON_SAVE}
            </Button>
          </Tooltip>
        </Col>
      </Row>
    </div>
  );
}
