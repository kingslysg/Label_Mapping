import { Button, Col, Row } from "antd"
import * as Constants from '../util/constants';

const UnmappedSelectionBtn = () => {


    return (<div>
        <Row>
            <Col className="unmapped-reset-col">
                <Button className='defaultButtonStyle'>
                    {Constants.BUTTON_RESET}
                </Button>
            </Col>
            <Col>
                <Button className='selectedButtonStyle'>
                    {Constants.BUTTON_CREATE_RULE}
                </Button>
            </Col>
        </Row>
    </div>)
}

export default UnmappedSelectionBtn;