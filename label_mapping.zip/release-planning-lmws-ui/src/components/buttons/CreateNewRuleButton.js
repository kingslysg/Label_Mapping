import React, { useState } from 'react';
import { Row, Col, Button, Tooltip } from 'antd';
import * as Constants from '../util/constants';


export default function CreateNewRuleButton({ disableRest, disableSearch, onResetClick, onSearchclick }) {

  const handleResetClick = () => {
    onResetClick();
  };

  const handleSearchClick = () => {
    onSearchclick();
  };

  return (
    <div>
      <Row>
        <Col className="search-reset-col">
          <Button
            disabled={disableRest}
            className='defaultButtonStyle'
            onClick={handleResetClick}
          >
            {Constants.BUTTON_RESET}
          </Button>
        </Col>
        <Col>
          <Tooltip title={disableSearch ? Constants.BUTTON_CREATE_RULE_TOOLTIP : ''} >
            <Button
              disabled={disableSearch}
              className='selectedButtonStyle'
              type="primary"
              onClick={handleSearchClick}
            >
              {Constants.BUTTON_CREATE_RULE}
            </Button>
          </Tooltip>
        </Col>
      </Row>
    </div>
  );
}
