import { Button } from "antd";
import { ExportOutlined } from "@ant-design/icons";
import * as Constants from '../util/constants';

export const ExportResultsButton = ({ handleClick, buttonText = Constants.BUTTON_EXPORT_RESULTS }) => (
    <Button className="search-home-header" onClick={handleClick}>
        {buttonText} <ExportOutlined />
    </Button>
);

export default ExportResultsButton;