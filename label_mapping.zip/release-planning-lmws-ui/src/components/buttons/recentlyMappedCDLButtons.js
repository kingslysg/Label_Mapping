import { useState } from "react";
import { Button } from "antd";
import * as Constants from "../util/constants";
import CDLMappingDetailsModal from '../views/cdl-mapping-details/ModalCdlMappingDetails';

export const useFilterActions = (dataSource, countries) => {
    const [searchText, setSearchText] = useState("");
    const [selectedFilters, setSelectedFilters] = useState([]);
    const [selectedFiltersOther, setSelectedFiltersOther] = useState({});
    const [filteredCountries, setFilteredCountries] = useState(countries);
    const [filteredData, setFilteredData] = useState(dataSource);
    const [highlightedFilters, setHighlightedFilters] = useState({});

    const applyCombinedFilters = () => {
        let filtered = dataSource;

        // Apply domCountry filter
        if (selectedFilters.length > 0) {
            filtered = filtered.filter((record) => selectedFilters.includes(record.domCountry));
        }

        Object.keys(selectedFiltersOther).forEach((dataIndex) => {
            const filters = selectedFiltersOther[dataIndex] || [];
            if (filters.length > 0) {
                filtered = filtered.filter((record) => filters.includes(record[dataIndex]));
            }
        });

        setFilteredData(filtered);
        setHighlightedFilters((prev) => ({
            ...prev,
            domCountry: selectedFilters.length > 0,
            ...Object.fromEntries(
                Object.keys(selectedFiltersOther).map((key) => [key, (selectedFiltersOther[key] || []).length > 0])
            ),
        }));
    };

    const handleFilterSaveSearch = () => {
        applyCombinedFilters();
    };

    const handleFilterSaveSearchOther = () => {
        applyCombinedFilters();
    };

    const handleResetButton = () => {
        setSearchText("");
        setSelectedFilters([]);
        setSelectedFiltersOther({});
        setFilteredCountries(countries);
        setFilteredData(dataSource);
        setHighlightedFilters({});
    };

    const handleResetButtonOther = (dataIndex) => {
        // Reset only the specified filter without affecting others
        setSelectedFiltersOther((prev) => ({ ...prev, [dataIndex]: [] }));

        // Re-apply combined filters
        let filtered = dataSource;

        // Apply domCountry filter if any filters are selected
        if (selectedFilters.length > 0) {
            filtered = filtered.filter((record) => selectedFilters.includes(record.domCountry));
        }

        // Reapply other filters except the reset one
        Object.keys(selectedFiltersOther).forEach((key) => {
            if (key !== dataIndex) {
                const filters = selectedFiltersOther[key] || [];
                if (filters.length > 0) {
                    filtered = filtered.filter((record) => filters.includes(record[key]));
                }
            }
        });

        setFilteredData(filtered);
        setHighlightedFilters((prev) => ({ ...prev, [dataIndex]: false })); // Clear highlight for the reset column
    };

    return {
        searchText,
        setSearchText,
        selectedFilters,
        setSelectedFilters,
        selectedFiltersOther,
        setSelectedFiltersOther,
        filteredCountries,
        setFilteredCountries,
        filteredData,
        setFilteredData,
        highlightedFilters,
        handleFilterSaveSearch,
        handleFilterSaveSearchOther,
        handleResetButton,
        handleResetButtonOther,
    };
};

// Define button components
export const ResetButton = ({ handleClick }) => (
    <Button onClick={handleClick} size="small">{Constants.BUTTON_RESET}</Button>
);

export const SaveButton = ({ handleClick }) => (
    <Button type="primary" onClick={handleClick} size="small">{Constants.BUTTON_SAVE}</Button>
);

export const ResetOtherButton = ({ handleClick }) => (
    <Button onClick={handleClick} size="small">{Constants.BUTTON_RESET}</Button>
);

export const SaveOtherButton = ({ handleClick }) => (
    <Button type="primary" onClick={handleClick} size="small">{Constants.BUTTON_SAVE}</Button>
);

// Updated DetailsButton component
export const DetailsButton = ({ handleClick, selectedData }) => {
    const [isModalVisible, setIsModalVisible] = useState(false);

    const handleButtonClick = () => {
        setIsModalVisible(true);
        if (handleClick) handleClick();
    };

    return (
        <>
            <Button
                className="recently-mapped-details-button"
                type="link"
                onClick={handleButtonClick}
            >
                {Constants.BUTTON_DETAILS}
            </Button>
            {isModalVisible && (
                <CDLMappingDetailsModal
                    isVisible={isModalVisible}
                    onClose={() => setIsModalVisible(false)}
                    selectedData={selectedData} 
                />
            )}
        </>
    );
};


// Assign all exports to a variable before exporting as default
const RecentlyMappedCDLButtons = {
    ResetButton,
    SaveButton,
    ResetOtherButton,
    SaveOtherButton,
    DetailsButton,
    useFilterActions,
};

export default RecentlyMappedCDLButtons;
