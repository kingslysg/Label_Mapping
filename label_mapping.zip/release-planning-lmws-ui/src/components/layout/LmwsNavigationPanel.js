import React, { useState } from 'react';
import { Layout } from 'antd';
import { BrowserRouter as Router } from 'react-router-dom';
import { MenuUnfoldOutlined, MenuFoldOutlined } from '@ant-design/icons';

import HeaderPanel from '../header/HeaderPanel';
import MenuComponent from '../layout/sidebar/MenuComponent';
import RoutesComponent from './sidebar/RoutesComponent'; 
import MenuSider from './sidebar/MenuSider';

export default function LmwsNavigationPanel() {
  const [collapsed, setCollapsed] = useState(true);
  const { Content, Footer, Sider } = Layout;

  return (
    <Layout>
      <HeaderPanel />
      <Layout className='layout-panel'>
        <Router>
        
          <MenuSider collapsed={collapsed} setCollapsed={setCollapsed} />

          <Layout>
            <Content>
                  <RoutesComponent />
            </Content>
          </Layout>

        </Router>
      </Layout>
    </Layout>
  );
}
