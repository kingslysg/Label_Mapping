import React from 'react';
import { Route, Routes } from 'react-router-dom';
import HomePage from '../../views/Home';
import UnMappedCDLPage from '../../views/unmapped-cdls/UnmappedCDL';
import CreateRulePage from '../../views/CreateRule';
import AccountPage from '../../views/Account';
import SearchMappings from '../../views/search/SearchMappings';

const RoutesComponent = () => {
  return (
    <Routes>
      <Route path="/" element={<SearchMappings />} />
      <Route path="/home" element={<SearchMappings />} />
      <Route path="/unmappedCDL" element={<UnMappedCDLPage />} />
      <Route path="/createRule" element={<CreateRulePage />} />
      <Route path="/account" element={<AccountPage />} />
    </Routes>
  );
};

export default RoutesComponent;
