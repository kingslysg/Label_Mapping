import React from 'react';
import { Layout } from 'antd';
import { MenuUnfoldOutlined, MenuFoldOutlined } from '@ant-design/icons';
import MenuComponent from './MenuComponent';
import RectangleSidebarSvgImage from '../../images/svg-components/RectangleSidebarSVG';


const MenuSider = ({ collapsed, setCollapsed }) => {
  const { Sider } = Layout;

  const toggleCollapsed = () => {
    setCollapsed(!collapsed);
  };

  return (
    <Sider
      collapsible
      collapsed={collapsed}
      collapsedWidth={48} // Width when collapsed
      width={192} // Width when uncollapsed
      onCollapse={(value) => setCollapsed(value)}
      trigger={
        <>
          <div className="horizontal-line" />
          {collapsed ? (
            <MenuUnfoldOutlined
              className={`MenuUnfoldOutlined-style ${collapsed ? 'unfold-collapsed' : 'unfold-uncollapsed'}`}
              onClick={toggleCollapsed}
            />
          ) : (
            <MenuFoldOutlined
              className={`MenuFoldOutlined-style ${collapsed ? 'fold-collapsed' : 'fold-uncollapsed'}`}
              onClick={toggleCollapsed}
            />
          )}
        </>
      }
      className="sider-shadow"
    >
      <div className="sider-content">
        <div className="menu-component">
          <MenuComponent />
        </div>

        <div className="image-container">
          <div
            className={`custom-image ${collapsed ? 'collapsed-image' : 'uncollapsed-image'}`} 
            onClick={toggleCollapsed}
            style={{ cursor: 'pointer' }} 
          >
            <RectangleSidebarSvgImage />
          </div>
        </div>
      </div>
    </Sider>
  );
};

export default MenuSider;
