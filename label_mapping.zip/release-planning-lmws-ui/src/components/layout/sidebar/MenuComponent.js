import React, { useState } from 'react';
import { Menu } from 'antd';
import { Link } from 'react-router-dom';
import {HomeOutlined,HomeFilled,ShareAltOutlined,ProfileOutlined,UserOutlined} from '@ant-design/icons';
import * as Constants from '../../util/constants'

const MenuComponent = () => {
  const [selectedKey, setSelectedKey] = useState('1');

  const handleMenuClick = (e) => {
    setSelectedKey(e.key);
  };

  return (
    <Menu theme="light" selectedKeys={[selectedKey]} mode="inline" onClick={handleMenuClick}>
      <Menu.Item 
        key="1" 
        icon={selectedKey === '1' ? <HomeFilled /> : 
        <HomeFilled className="home-unfilled-icon" />}
      >
        <Link to="/home">{Constants.LABEL_HOME}</Link>
      </Menu.Item>
      <Menu.Item 
        key="2" 
        icon={selectedKey === '2' ? <ShareAltOutlined /> : <ShareAltOutlined />}
      >
        <Link to="/unmappedCDL">Unmapped</Link>
      </Menu.Item>
      <Menu.Item 
        key="3" 
        icon={selectedKey === '3' ? <ProfileOutlined /> : <ProfileOutlined />}
      >
        <Link to="/createRule">Create Rule</Link>
      </Menu.Item>
      <Menu.Item 
        key="4" 
        icon={selectedKey === '4' ? <UserOutlined /> : <UserOutlined />}
      >
        <Link to="/account">Account</Link>
      </Menu.Item>
    </Menu>
  );
};

export default MenuComponent;
