import { Col, Input, Row } from "antd";
import { useEffect, useState } from "react";


const UnmappedDomesticCDL = ({ formValues, handleInputChange }) => {
    const [isCountryFilled, setIsCountryFilled] = useState(false);
    const [isFamilyFilled, setIsFamilyFilled] = useState(false);
    const [isCompanyFilled, setIsCompanyFilled] = useState(false);
    const [isDivisionFilled, setIsDivisionFilled] = useState(false);
    const [isLabelFilled, setIsLabelFilled] = useState(false);

    useEffect(() => {
        setIsCountryFilled(!!formValues.d_country);
        setIsFamilyFilled(!!formValues.d_family);
        setIsCompanyFilled(!!formValues.d_company);
        setIsDivisionFilled(!!formValues.d_division);
        setIsLabelFilled(!!formValues.d_label);
    }, [formValues]);

    return (
        <div className='search-cdl'>
            <Row gutter={[10, 10]}>

                {/* Country Input */}
                <Col className='search-input-country search-col-style-attributes-unmapped'>
                    {isCountryFilled && (
                        <span className="searchfield-text-style">
                            Country
                        </span>
                    )}
                    <Input
                        placeholder="Input Country"
                        allowClear
                        value={formValues.d_country}
                        onChange={(e) => handleInputChange('d_country', e.target.value)}
                        className="search-field-input-style custom-disabled-input"
                        disabled
                    />
                </Col>

                {/* Family Input */}
                <Col className='unmapped-search-input search-col-style-attributes-unmapped'>
                    {isFamilyFilled && (
                        <span className="searchfield-text-style">
                            Family
                        </span>
                    )}
                    <Input
                        placeholder="Input Family"
                        allowClear
                        value={formValues.d_family}
                        onChange={(e) => handleInputChange('d_family', e.target.value)}
                        className="search-field-input-style"
                    />
                </Col>

                {/* Company Input */}
                <Col className='unmapped-search-input search-col-style-attributes-unmapped'>
                    {isCompanyFilled && (
                        <span className="searchfield-text-style">
                            Company
                        </span>
                    )}
                    <Input
                        placeholder="Input Company"
                        allowClear
                        value={formValues.d_company}
                        onChange={(e) => handleInputChange('d_company', e.target.value)}
                        className="search-field-input-style"
                    />
                </Col>

                {/* Division Input */}
                <Col className='unmapped-search-input search-col-style-attributes-unmapped'>
                    {isDivisionFilled && (
                        <span className="searchfield-text-style">
                            Division
                        </span>
                    )}
                    <Input
                        placeholder="Input Division"
                        allowClear
                        value={formValues.d_division}
                        onChange={(e) => handleInputChange('d_division', e.target.value)}
                        className="search-field-input-style"
                    />
                </Col>

                {/* Label Input */}
                <Col className='unmapped-search-input search-col-style-attributes-unmapped'>
                    {isLabelFilled && (
                        <span className="searchfield-text-style">
                            Label
                        </span>
                    )}
                    <Input
                        placeholder="Input Label"
                        allowClear
                        value={formValues.d_label}
                        onChange={(e) => handleInputChange('d_label', e.target.value)}
                        className="search-field-input-style"
                    />
                </Col>

            </Row>
        </div>
    );
}
export default UnmappedDomesticCDL;