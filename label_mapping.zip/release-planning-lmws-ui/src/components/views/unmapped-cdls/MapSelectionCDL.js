
import React, { useEffect, useState } from "react";
import * as Constants from '../../util/constants';
import UnmappedDomesticCDL from "./UnmappedDomesticCDL";
import UnmappedSelectionBtn from "../../buttons/unmappedSelectionBtn";
import UnmappedInternationalCDL from "./unmappedIntCDL";

const MapSelectionCDL = ({ selectedRows }) => {

    const computedInitiaValues = (rows) => {
        if (rows.length === 1) {
            //populate all fields with the single row's data
            return {
                d_country: rows[0]?.domesticCountry || '',
                d_family: rows[0]?.domesticFamily || '',
                d_company: rows[0]?.domesticCompany || '',
                d_division: rows[0]?.domesticDivision || '',
                d_label: rows[0]?.domesticLabel || '',
                i_country: rows[0]?.internationalMapping || '', // Autopopulated

            };
        }

        // For multiple rows, calculate common values
        const fields = [
            'domesticCountry',
            'domesticFamily',
            'domesticCompany',
            'domesticDivision',
            'domesticLabel',
            'internationalMapping',

        ];

        const commonValues = {};

        fields.forEach((field) => {
            const allValues = rows.map((row) => row[field]); // Extract all values for the field
            const uniqueValues = [...new Set(allValues)]; // Get unique values

            // If all values are the same, use that value; otherwise, leave empty
            commonValues[field] = uniqueValues.length === 1 ? uniqueValues[0] : '';
        });

        return {
            d_country: commonValues.domesticCountry || '',
            d_family: commonValues.domesticFamily || '',
            d_company: commonValues.domesticCompany || '',
            d_division: commonValues.domesticDivision || '',
            d_label: commonValues.domesticLabel || '',
            i_country: commonValues.internationalMapping || '',

        };
    };

    // const [formValues, setFormValues] = useState({
    //     d_country: selectedRows[0]?.domesticCountry || '',
    //     d_family: selectedRows[0]?.domesticFamily || '',
    //     d_company: selectedRows[0]?.domesticCompany || '',
    //     d_division: selectedRows[0]?.domesticDivision || '',
    //     d_label: selectedRows[0]?.domesticLabel || '',
    //     i_country: selectedRows[0]?.internationalMapping || '', // Autopopulated
    // });


    // const handleInputChange = (field, value) => {
    //     const updatedValues = {
    //         ...formValues, [field]: value
    //     };
    //     setFormValues(updatedValues);
    // }

    const [formValues, setFormValues] = useState(computedInitiaValues(selectedRows));

    useEffect(() => {
        setFormValues(computedInitiaValues(selectedRows));// Update formValues on selectedRows change
    }, [selectedRows]);

    const handleInputChange = (field, value) => {
        setFormValues((prev) => ({ ...prev, [field]: value }));
    };

    if (selectedRows.length === 0) return null; // Don't render if no rows are selected
    return (
        <div>
            <div className="unmapped-text-header-space">
                <span className="unmapped-text-header-label"> {Constants.LABEL_UNMAPPED_CDLS_MAP_TEXT}</span>
            </div>

            <div className='search-cdl unmapped-domestic-txt'>
                <span className='ummapped-label '>  {Constants.LABEL_DOMESTIC_CDL}</span>
            </div>

            <div className="unmapped-domestic-cdl-space">
                <UnmappedDomesticCDL
                    formValues={formValues}
                    handleInputChange={handleInputChange}
                />
            </div>
            <br />
            <div className='search-cdl'>
                <span className='ummapped-label'>  {Constants.LABEL_INTERNATIONAL_CDL}</span>
            </div>
            <div className="unmapped-domestic-cdl-space">
                <UnmappedInternationalCDL
                    formValues={formValues}
                    handleInputChange={handleInputChange} />
            </div>

            <div className='unmapped-button'>
                <UnmappedSelectionBtn />
            </div>
        </div>
    )
}

export default MapSelectionCDL;