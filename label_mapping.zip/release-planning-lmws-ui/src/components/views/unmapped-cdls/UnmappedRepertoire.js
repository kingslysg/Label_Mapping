import React, { useRef, useState } from 'react';
import {
  CaretDownFilled,
  CaretUpFilled,
  DesktopOutlined,
  FileOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Checkbox, Input, Layout, Menu, Table, theme } from 'antd';
import ExportResultsButton from '../../buttons/ExportButton';
import * as Constants from "../../util/constants";
import PaginationConfig from '../../util/PaginationConfig';
import '../../stylesheet/lmws.css';
import '../../stylesheet/unmappedCDL.css';
import RecentlyMappedCDLButtons, { useFilterActions } from '../../buttons/recentlyMappedCDLButtons';
import SearchButtons from "../../buttons/searchButtons";

import DomesticCDL from '../search/domesticCDL';
import InternationalCDL from '../search/internationalCDL';

const UnMappedRepertoireTable = ({dataSource, rowSelectionChanged}) => {

  const inputRef = useRef(null);
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();
  const { Content, Footer, Sider } = Layout;

  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [data, setData] = useState([]);
  const [collapsed, setCollapsed] = useState(false);
  const [isSearchDisabled, setIsSearchDisabled] = useState(true); // Default disabled
  const [chcekboxKeyValue, setChcekboxKeyValue] = useState(true); // Default disabled
  const [hideMappingTable, setHideMappingTable] = useState(true);
  const [createRuleDisabled, setCreateRuleDisabled] = useState(true);

  const [disabledRowKeys, setDisabledRowKeys] = useState([]);
  const [selectedRowsData, setSelectedRowsData] = useState([]);
  const [checkboxChecked, setCheckboxChecked] = useState(false);

  // State to manage input fields
  const [formValues, setFormValues] = useState({
    d_country: '',
    d_family: '',
    d_company: '',
    d_division: '',
    d_label: '',
    d_artist: '',
    d_project: '',
    i_country: '',
    i_company: '',
    i_division: '',
    i_label: ''
  });

  // Enable/disable input fields
  const [formValueDisabled, setFormValueDisabled] = useState({
    d_country: true,
    d_family: false,
    d_company: false,
    d_division: false,
    d_label: false,
    d_artist: false,
    d_project: false
  });


  const dataSourceCopy = Array.from(new Set(dataSource)).map((source) => ({
    d_country:  source.domesticCountry,
    d_family:   source.domesticFamily,
    d_division: source.domesticDivision,
    d_company:  source.domesticCompany,
    d_label:    source.domesticLabel,
    d_artist:   source.artist,
    d_project:  source.domesticProject,
    i_country:  source.internationalMapping,
  }));

  // console.log(dataSource.map(x => x.domesticCompany));
  // console.log(dataSourceCopy.map(x => x.i_country));

  const onSelectChange = (newSelectedRowKeys) => {
    console.log('selectedRowKeys changed: ', newSelectedRowKeys);
    setSelectedRowKeys(newSelectedRowKeys);
    rowSelectionChanged(newSelectedRowKeys);
    setHideMappingTable(newSelectedRowKeys.length === 0);
    if (newSelectedRowKeys.length === 0) {
      setCheckboxChecked(false);
    }

    // Filter out incompatible options
    const selectedData = filteredData.filter((row) =>
      newSelectedRowKeys.includes(row.key)
    );

    // Identify incompatible rows
    const incompatibleKeys = filteredData
      .filter((row) =>
        selectedData.some(
          (selectedRow) =>
            // Example: Conflicting if international mapping differs
            selectedRow.domesticCountry !== row.domesticCountry ||
            selectedRow.internationalMapping !== row.internationalMapping
        )
      )
      .map((row) => row.key);

    setDisabledRowKeys(incompatibleKeys)
    setSelectedRowsData(selectedData); // save selected row data

    if (newSelectedRowKeys.length >= 1) {
      var index = newSelectedRowKeys[0] - 1;
      console.log("index:", index);
      dataSourceCopy[0].d_country  = dataSource[index].domesticCountry;
      dataSourceCopy[0].d_family   = dataSource[index].domesticFamily;
      dataSourceCopy[0].d_division = dataSource[index].domesticDivision;
      dataSourceCopy[0].d_company  = dataSource[index].domesticCompany;
      dataSourceCopy[0].d_label    = dataSource[index].domesticLabel;
      dataSourceCopy[0].d_artist   = dataSource[index].artist;
      dataSourceCopy[0].d_project  = dataSource[index].domesticProject;
      dataSourceCopy[0].i_country  = dataSource[index].internationalMapping;

      if (newSelectedRowKeys.length > 1) {
        for (var i = 1; i < newSelectedRowKeys.length; i++) {
          index = newSelectedRowKeys[i] - 1;
          console.log("index:", index);
          console.log("dataSource:", dataSource[index]);
          if (dataSource[index].domesticCountry === dataSourceCopy[0].d_country && 
              dataSource[index].internationalMapping === dataSourceCopy[0].i_country) {

            if (dataSource[index].domesticFamily !== dataSourceCopy[0].d_family) {
              dataSourceCopy[0].d_family = "";
            }

            if (dataSource[index].domesticCompany !== dataSourceCopy[0].d_company) {
              dataSourceCopy[0].d_company = "";
            }
            
            if (dataSource[index].domesticDivision !== dataSourceCopy[0].d_division) {
              dataSourceCopy[0].d_division = "";
            }

            if (dataSource[index].domesticLabel !== dataSourceCopy[0].d_label) {
              dataSourceCopy[0].d_label = "";
            }

            if (dataSource[index].artist !== dataSourceCopy[0].d_artist) {
              dataSourceCopy[0].d_artist = "";
            }

            if (dataSource[index].domesticProject !== dataSourceCopy[0].d_project) {
              dataSourceCopy[0].d_project = "";
            }

          } else {
            newSelectedRowKeys.pop(); // Remove the last selected row.
            alert("Please select rows of the same Domestic country and International country");
            break;
          }
        }
      }

      setFormValues(dataSourceCopy[0]);
    }
  }

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
    getCheckboxProps: (record) => ({
      disabled: disabledRowKeys.includes(record.key),
    }),
  };

  const {
    filteredData,
    searchText,
    setSearchText,
    setSelectedFiltersOther,
    selectedFiltersOther,
    handleResetButtonOther,
    handleFilterSaveSearchOther,
    highlightedFilters

  } = useFilterActions(dataSource)

  const columns = [
    {
      title: "Domestic Country",
      dataIndex: "domesticCountry",
      key: "domesticCountry",
      className: `custom-header-style ${highlightedFilters.domesticCountry ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticCountry.localeCompare(b.domesticCountry),
      filterDropdown: () => renderFilterDropdown("domesticCountry"),
    },
    {
      title: "Domestic Family",
      dataIndex: "domesticFamily",
      key: "domesticFamily",
      className: `custom-header-style ${highlightedFilters.domesticFamily ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticFamily.localeCompare(b.domesticFamily),
      filterDropdown: () => renderFilterDropdown("domesticFamily"),
    },
    {
      title: "Domestic Company",
      dataIndex: "domesticCompany",
      key: "domesticCompany",
      className: `custom-header-style ${highlightedFilters.domesticCompany ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticCompany.localeCompare(b.domesticCompany),
      filterDropdown: () => renderFilterDropdown("domesticCompany"),
    },
    {
      title: "Domestic Division",
      dataIndex: "domesticDivision",
      key: "domesticDivision",
      className: `custom-header-style ${highlightedFilters.domesticDivision ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticDivision.localeCompare(b.domesticDivision),
      filterDropdown: () => renderFilterDropdown("domesticDivision"),
    },
    {
      title: "Domestic Label",
      dataIndex: "domesticLabel",
      key: "domesticLabel",
      className: `custom-header-style ${highlightedFilters.domesticLabel ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticLabel.localeCompare(b.domesticLabel),
      filterDropdown: () => renderFilterDropdown("domesticLabel"),
    },
    {
      title: "Artist",
      dataIndex: "artist",
      key: "artist",
      className: `custom-header-style ${highlightedFilters.artist ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.artist.localeCompare(b.artist),
      filterDropdown: () => renderFilterDropdown("artist"),
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      className: `custom-header-style ${highlightedFilters.title ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.title.localeCompare(b.title),
      filterDropdown: () => renderFilterDropdown("title"),
    },
    {
      title: "UPC/ISRC",
      dataIndex: "upcIsrc",
      key: "upcIsrc",
      className: `custom-header-style ${highlightedFilters.upcIsrc ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.upcIsrc.localeCompare(b.upcIsrc),
      filterDropdown: () => renderFilterDropdown("upcIsrc"),
    },
    {
      title: "Domestic ProjectID",
      dataIndex: "domesticProject",
      key: "domesticProject",
      className: `custom-header-style ${highlightedFilters.upcIsrc ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticProject.localeCompare(b.domesticProject),
      filterDropdown: () => renderFilterDropdown("domesticProject"),
    },
    {
      title: "Date of Entry",
      dataIndex: "dateOfEntry",
      key: "dateOfEntry",
      width: 150,
      fixed: 'right',
      className: `custom-header-style ${highlightedFilters.dateOfEntry ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => new Date(a.dateOfEntry) - new Date(b.dateOfEntry),
      filterDropdown: () => renderFilterDropdown("dateOfEntry")
    },
    {
      title: "International mapping for:",
      dataIndex: "internationalMapping",
      key: "internationalMapping",
      width: 150,
      fixed: "right",
      className: `custom-header-style ${highlightedFilters.internationalMapping ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.internationalMapping.localeCompare(b.internationalMapping),
      filterDropdown: () => renderFilterDropdown("internationalMapping")
    }
  ]

  const getRowClassName = (record) => {
    return disabledRowKeys.includes(record.key) ? 'row-disabled' : '';
  };

  const getUniqueValues = (dataIndex) => {

    const values = dataSource.map((item) => item[dataIndex]);
    const uniqueValues = Array.from(new Set(values)).map((value) => ({
      label: value,
      value,
    }));
    return uniqueValues;
  }

  const handleFilterChange = (dataIndex, value) => {
    setSelectedFiltersOther((prev) => {
      const currentFilters = prev[dataIndex] || [];
      const updatedFilters = currentFilters.includes(value)
        ? currentFilters.filter((filter) => filter !== value)
        : [...currentFilters, value];
      return { ...prev, [dataIndex]: updatedFilters };
    })
  }

  const handleSearchTextChange = (value, options) => {
    return options.filter((option) =>
      option.label.toLowerCase().includes(value.toLowerCase()))
  }

  const handleCheckboxChange = () => {
    setCheckboxChecked(!checkboxChecked);
  }

  const renderFilterDropdown = (dataIndex) => {
    const options = getUniqueValues(dataIndex);
    return (
      <div className="filter-dropdown-container">
        <div className="filter-dropdown-header">
          <span className="filter-label">Filter:</span>
          <Input
            ref={inputRef}
            placeholder="Search"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="filter-input"
          />
        </div>
        <div className="filter-checkbox-list">
          {handleSearchTextChange(searchText, options).map((option) => (
            <Checkbox
              key={option.value}
              checked={(selectedFiltersOther[dataIndex] || []).includes(option.value)}
              onChange={() => handleFilterChange(dataIndex, option.value)}
            >
              {option.label}
            </Checkbox>
          ))}
        </div>
        <div className="filter-dropdown-actions">
          <RecentlyMappedCDLButtons.ResetOtherButton handleClick={() => handleResetButtonOther(dataIndex)} />
          <RecentlyMappedCDLButtons.SaveOtherButton handleClick={() => handleFilterSaveSearchOther(dataIndex)} />
        </div>
      </div>
    )
  }

  const exportButtonClicked = () => {
  }

  // Handle input change
  const handleInputChange = (field, value) => {
    const updatedValues = {
        ...formValues,
        [field]: value
    };

    console.log(field, value);

    setFormValues(updatedValues);

    var filledValuesCount = 0;
    for (let key in updatedValues) {
      // console.log(key, updatedValues[key]);
      if ((key === 'i_country' || key === 'i_company' || key === 'i_division' || key === 'i_label') &&
          updatedValues[key] !== "") {
        filledValuesCount++;
      }
    }

    // console.log("filledValuesCount:", filledValuesCount);

    if (filledValuesCount === 4) {
      // All fields have values for international C/D/L.
      setCreateRuleDisabled(false);
      setIsSearchDisabled(false);
      setCheckboxChecked(true);
    } else {
      setCreateRuleDisabled(true);
      setIsSearchDisabled(true);
      setCheckboxChecked(false);
    }
  };

  // Reset function to clear inputs and disable search button
  const handleReset = () => {
    // setFormValues({
    //     d_country: '',
    //     d_family: '',
    //     d_company: '',
    //     d_division: '',
    //     d_label: '',
    //     d_artist: '',
    //     d_project: '',
    //     i_country: '',
    //     i_company: '',
    //     i_division: '',
    //     i_label: ''
    // });
    setIsSearchDisabled(true); // Disable search button after reset
  };

   // Reset function to clear inputs and disable search button
   const handleSearch = () => {
    // alert("comming soon => country=" + formValues.d_country +
    //     "&d_family=" + formValues.d_family +
    //     "&d_company=" + formValues.d_company +
    //     "&d_division=" + formValues.d_division +
    //     "&d_label=" + formValues.d_label +
    //     "&d_artist=" + formValues.d_artist +
    //     "&d_project=" + formValues.d_project +
    //     "&i_country=" + formValues.i_country +
    //     "&i_company=" + formValues.i_company +
    //     "&i_division=" + formValues.i_division +
    //     "&i_label=" + formValues.i_label
    // );
  };


  const paginationConfig = PaginationConfig(dataSource);

  return (
    <div>
      <div className="unmapped-header-container">
        <span className="unmapped-down-icon"
          onClick={() => setCollapsed(!collapsed)}
          style={{ cursor: 'pointer' }}
        >
          {collapsed ? <CaretUpFilled /> : <CaretDownFilled />}
        </span>
        <span className="unmapped-header-text">
          {Constants.LABEL_UNASSOCIATED_REPERTOIRE}
        </span>
        <div className="unmapped-export-button">
          <ExportResultsButton handleClick = {exportButtonClicked} />
        </div>
      </div>
      {!collapsed && (
        <>
          <div className='unmapped-result-text-space'>
            <span className="unmapped-result-text">
              {Constants.LABEL_UNASSOCIATED_REPERTOIRE_TEXT}
            </span>
          </div>

          <Table
            pagination={paginationConfig}
            size='small'
            rowSelection={rowSelection}
            columns={columns}
            dataSource={filteredData}
            locale={{
              emptyText: (
                <div className='unmapped-table-text'>
                  <span>{Constants.LABEL_UNMAPPED_CDLS_TABLE_NO_UNASSOCIATED_REPERTOIRE_TEXT}</span>
                </div>
              )
            }}
            className="custom-table-style"
            scroll={{
              x: 'max-content'
            }}
            rowClassName={getRowClassName}
          >
          </Table>
        </>
      )}

      <div className="associate-selected-repertoire-container" hidden={hideMappingTable}>
        <span className="associate-selected-repertoire-text">
          {Constants.LABEL_ASSOCIATE_SELECTED_REPERTOIRE_TEXT}
        </span>
        <div className='search-cdl'>
          <span className='search-label'> {Constants.LABEL_DOMESTIC_CDL}</span>
        </div>
        <DomesticCDL
          formValues={formValues}
          handleInputChange={handleInputChange}
          formValueDisabled={formValueDisabled} />

        <div/>
        <div className='search-cdl'>
          <span className='search-label'> {Constants.LABEL_INTERNATIONAL_CDL}</span>
        </div>
        <InternationalCDL
          formValues={formValues}
          handleInputChange={handleInputChange} />

        <div class="associate-selected-repertorie-container">
          <div class="associate-selected-repertorie-start">
            <Checkbox style={{fontFamily:'Roboto', fontSize:'16px', backgroundColor:'white'}}
              key={chcekboxKeyValue}
              disabled={createRuleDisabled}
              defaultChecked={true}
              checked={checkboxChecked}
              onChange={() => handleCheckboxChange()}
              >
              {'Create rule to apply to repertoire going forward.'}
            </Checkbox>
          </div>
          <div class="associate-selected-repertorie-end">
            <SearchButtons disableRest={isSearchDisabled}
              disableSearch={isSearchDisabled}
              onResetClick={handleReset}
              onSearchclick={handleSearch}
              showSave={true}
            >
            {Constants.LABEL_INTERNATIONAL_CDL}
            </SearchButtons>
          </div>
        </div>
      </div>
    </div>
  )
};

export default UnMappedRepertoireTable;
