import React, { useRef, useState } from 'react';
import {
  CaretDownFilled,
  CaretUpFilled,
  DesktopOutlined,
  FileOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Breadcrumb, Checkbox, Input, Layout, Menu, Table, theme } from 'antd';
import ExportResultsButton from '../../buttons/ExportButton';
import * as Constants from "../../util/constants";
import PaginationConfig from '../../util/PaginationConfig';
import RecentlyMappedCDLButtons, { useFilterActions } from '../../buttons/recentlyMappedCDLButtons';
import UnMappedRepertoireTable from './UnmappedRepertoire';
import InternationalCDL from '../search/internationalCDL';
import MapSelectionCDL from './MapSelectionCDL';

const dataSourceSample = [

  {
    key: "1",
    domesticCountry: "US",
    domesticFamily: "IGA",
    domesticCompany: "21 Entertainment",
    domesticDivision: "Camylio",
    domesticLabel: "Universal Prod label",
    dateOfEntry: "01 Oct 2024",
    artist: "Camylio",
    title: "ghost me",
    upcIsrc: "00602458836318",
    domesticProject: "BRPJ-04276",
    internationalMapping: "UE",
  },

  {
    key: "2",
    domesticCountry: "South Korea",
    domesticFamily: "EAU",
    domesticCompany: "40 Entertainment",
    domesticDivision: "Lio",
    domesticLabel: "pro Label",
    artist: "Camylio",
    title: "Sweet Nightmare",
    upcIsrc: "00602465235036",
    domesticProject: "GBPC-10292",
    dateOfEntry: "01 Dec 2023",
    internationalMapping: "SK",
  },

  {
    key: "3",
    domesticCountry: "England",
    domesticFamily: "COM",
    domesticCompany: "21 Entertainment",
    domesticDivision: "com division",
    domesticLabel: "engeal label",
    dateOfEntry: "06 Oct 2021",
    artist: "Will Linley",
    title: "Magic (Acoustic)",
    upcIsrc: "00602458836318",
    domesticProject: "IRIS-3369",
    internationalMapping: "UE",
  },

  {
    key: "4",
    domesticCountry: "US",
    domesticFamily: "IGA",
    domesticCompany: "Spain Entertainment",
    domesticDivision: "SIN Division",
    domesticLabel: "spain universal",
    dateOfEntry: "11 March 2024",
    artist: "Chumbawamba",
    title: "A Singsong And A Scrap",
    upcIsrc: "00602465394757",
    domesticProject: "GBPC-10292",
    internationalMapping: "UE",
  },

  {
    key: "5",
    domesticCountry: "US",
    domesticFamily: "LANG",
    domesticCompany: "LANG Com",
    domesticDivision: "LANG Division",
    domesticLabel: " Prod label",
    dateOfEntry: "01 June 2000",
    artist: "Chumbawamba",
    title: "A Singsong And A Scrap",
    upcIsrc: "00602465394757",
    domesticProject: "GBPC-10292",
    internationalMapping: "UE",
  },
  {
    key: "6",
    domesticCountry: "Japan",
    domesticFamily: "JPA",
    domesticCompany: "JPA Com",
    domesticDivision: "JPA Division",
    domesticLabel: "JPA UNIVERSAL",
    dateOfEntry: "24 July 2024",
    artist: "Kike M",
    title: "Cantares de arcilla",
    upcIsrc: "00602468073505",
    domesticProject: "DEPJ-62396",
    internationalMapping: "ZE",
  },

  {
    key: "7",
    domesticCountry: "US",
    domesticFamily: "IGA",
    domesticCompany: "21 Entertainment",
    domesticDivision: "Camylio",
    domesticLabel: "Universal Prod label",
    dateOfEntry: "01 Sep 2024",
    artist: "HITMAKER, Seu Jorge, MC Saci",
    title: "Amiga Da Minha Mulher - MTG",
    upcIsrc: "00602465994674",
    domesticProject: "DEPJ-62396",
    internationalMapping: "VA",
  },
]
export default function UnMappedCDLPage() {
  const inputRef = useRef(null);
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();
  const { Content, Footer, Sider } = Layout;

  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [data, setData] = useState([]);
  const [collapsed, setCollapsed] = useState(false);
  const [disabledRowKeys, setDisabledRowKeys] = useState([]);
  const [selectedRowsData, setSelectedRowsData] = useState([]);

  const {
    filteredData,
    searchText,
    setSearchText,
    setSelectedFiltersOther,
    selectedFiltersOther,
    handleResetButtonOther,
    handleFilterSaveSearchOther,
    highlightedFilters

  } = useFilterActions(dataSourceSample)

  const canSelectAll = () => {
    const uniqueInternationalMapping = [
      ...new Set(filteredData.map((row) => row.internationalMapping)),
    ];
    const uniqueDomesticCountry = [
      ...new Set(filteredData.map((row) => row.domesticCountry)),
    ];
    return uniqueInternationalMapping.length === 1 && uniqueDomesticCountry.length === 1;
  };

  const onSelectChange = (newSelectedRowKeys) => {
    console.log('selectedRowKeys changed: ', newSelectedRowKeys);

    const validKeys = newSelectedRowKeys.filter(
      (key) => !disabledRowKeys.includes(key)
    )

    // setSelectedRowKeys(newSelectedRowKeys);
    setSelectedRowKeys(validKeys);

    // Filter out incompatible options
    const selectedData = filteredData.filter((row) =>
      // newSelectedRowKeys.includes(row.key)
      validKeys.includes(row.key)
    );
    setSelectedRowsData(selectedData);

    // Identify incompatible rows
    const incompatibleKeys = filteredData
      .filter((row) =>
        selectedData.some(
          (selectedRow) =>
            // Example: Conflicting if international mapping differs and domestic country
            selectedRow.internationalMapping !== row.internationalMapping ||
            selectedRow.domesticCountry !== row.domesticCountry
        )
      )
      .map((row) => row.key);

    setDisabledRowKeys(incompatibleKeys)
    setSelectedRowsData(selectedData); // save selected row data


    // Disable incompatible checkboxes
    // const updatedData = dataSourceSample.map((row) => ({
    //   ...row,
    //   disabled: incompatibleKeys.includes(row.key),
    // }));
    // setData(updatedData);
  }

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
    onSelectAll: (selected) => {
      if (selected && canSelectAll()) {
        // Select all valid rows
        const allValidKeys = filteredData.map((row) => row.key);
        setSelectedRowKeys(allValidKeys);

        // Update selectedRowsData with all valid rows
        const allValidRows = filteredData.filter((row) =>
          allValidKeys.includes(row.key)
        );
        setSelectedRowKeys(allValidRows);
      } else {
        // Clear all selections
        setSelectedRowKeys([]);
        setSelectedRowsData([]); // Clear selected rows data
      }

    },
    getCheckboxProps: (record) => ({
      disabled: disabledRowKeys.includes(record.key),
    }),
    columnTitle: (
      <Checkbox
        onChange={(e) => {
          if (e.target.checked && canSelectAll()) {
            const allValidKeys = filteredData.map((row) => row.key);
            setSelectedRowKeys(allValidKeys);

            // Update selectedRowsData with all valid rows
            const allValidRows = filteredData.filter((row) =>
              allValidKeys.includes(row.key)
            );
            setSelectedRowsData(allValidRows);

          } else {
            setSelectedRowKeys([]);
            setSelectedRowsData([]); // Clear selected rows data
          }
        }}
        checked={filteredData.every((row) =>
          selectedRowKeys.includes(row.key)
        )}
        indeterminate={
          selectedRowKeys.length > 0 &&
          selectedRowKeys.length < filteredData.length
        }
        disabled={!canSelectAll()} // Disable header checkbox if conditions are not met
      />
    ),
  };

  const columns = [
    {
      title: "Domestic Country",
      dataIndex: "domesticCountry",
      key: "domesticCountry",
      className: `custom-header-style ${highlightedFilters.domesticCountry ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domCountry.localeCompare(b.domesticCountry),
      filterDropdown: () => renderFilterDropdown("domesticCountry"),
    },
    {
      title: "Domestic Family",
      dataIndex: "domesticFamily",
      key: "domesticFamily",
      className: `custom-header-style ${highlightedFilters.domesticFamily ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticFamily.localeCompare(b.domesticFamily),
      filterDropdown: () => renderFilterDropdown("domesticFamily"),
    },
    {
      title: "Domestic Company",
      dataIndex: "domesticCompany",
      key: "domesticCompany",
      className: `custom-header-style ${highlightedFilters.domesticCompany ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticCompany.localeCompare(b.domesticCompany),
      filterDropdown: () => renderFilterDropdown("domesticCompany"),
    },
    {
      title: "Domestic Division",
      dataIndex: "domesticDivision",
      key: "domesticDivision",
      className: `custom-header-style ${highlightedFilters.domesticDivision ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticivision.localeCompare(b.domesticDivision),
      filterDropdown: () => renderFilterDropdown("domesticDivision"),
    },
    {
      title: "Domestic Label",
      dataIndex: "domesticLabel",
      key: "domesticLabel",
      className: `custom-header-style ${highlightedFilters.domesticLabel ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.domesticLabel.localeCompare(b.domesticLabel),
      filterDropdown: () => renderFilterDropdown("domesticLabel"),
    },
    {
      title: "Date of Entry",
      dataIndex: "dateOfEntry",
      key: "dateOfEntry",
      width: 150,
      fixed: 'right',
      className: `custom-header-style ${highlightedFilters.dateOfEntry ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => new Date(a.dateOfEntry) - new Date(b.dateOfEntry),
      filterDropdown: () => renderFilterDropdown("dateOfEntry")
    },
    {
      title: "International mapping for:",
      dataIndex: "internationalMapping",
      key: "internationalMapping",
      width: 150,
      fixed: "right",
      className: `custom-header-style ${highlightedFilters.internationalMapping ? "highlighted-filter-icon" : "custom-value-style"} `,
      sorter: (a, b) => a.internationalMapping.localeCompare(b.internationalMapping),
      filterDropdown: () => renderFilterDropdown("internationalMapping")
    }
  ]

  const getRowClassName = (record) => {
    return disabledRowKeys.includes(record.key) ? 'row-disabled' : '';
  };


  const getUniqueValues = (dataIndex) => {

    const values = dataSourceSample.map((item) => item[dataIndex]);
    const uniqueValues = Array.from(new Set(values)).map((value) => ({
      label: value,
      value,
    }));
    return uniqueValues;
  }

  const handleFilterChange = (dataIndex, value) => {
    setSelectedFiltersOther((prev) => {
      const currentFilters = prev[dataIndex] || [];
      const updatedFilters = currentFilters.includes(value)
        ? currentFilters.filter((filter) => filter !== value)
        : [...currentFilters, value];
      return { ...prev, [dataIndex]: updatedFilters };
    })
  }

  const handleSearchTextChange = (value, options) => {
    return options.filter((option) =>
      option.label.toLowerCase().includes(value.toLowerCase()))
  }

  const renderFilterDropdown = (dataIndex) => {
    const options = getUniqueValues(dataIndex);
    return (
      <div className="filter-dropdown-container">
        <div className="filter-dropdown-header">
          <span className="filter-label">Filter:</span>
          <Input
            ref={inputRef}
            placeholder="Search"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="filter-input"
          />
        </div>
        <div className="filter-checkbox-list">
          {handleSearchTextChange(searchText, options).map((option) => (
            <Checkbox
              key={option.value}
              checked={(selectedFiltersOther[dataIndex] || []).includes(option.value)}
              onChange={() => handleFilterChange(dataIndex, option.value)}
            >
              {option.label}
            </Checkbox>
          ))}
        </div>
        <div className="filter-dropdown-actions">
          <RecentlyMappedCDLButtons.ResetOtherButton handleClick={() => handleResetButtonOther(dataIndex)} />
          <RecentlyMappedCDLButtons.SaveOtherButton handleClick={() => handleFilterSaveSearchOther(dataIndex)} />
        </div>
      </div>
    )
  }

  const UnMappedRepertoireRowSelectionChanged = (selectedRowKeys) => {
    if (selectedRowKeys.length > 0) {
      setCollapsed(true);
    }
  }

  const paginationConfig = PaginationConfig(dataSourceSample);

  return (
    <Layout className='layout-panel-unmapped'>
      <div className='unmapped-crumb'>
        <Content className='content-style'>

          <Breadcrumb className='breadcrumb-style'>
            {/* <Breadcrumb.Item>CDL</Breadcrumb.Item> */}

            <Breadcrumb.Item className='crumb-text'>{Constants.UNMAPPED}</Breadcrumb.Item>

          </Breadcrumb>


          <div style={{
            padding: 24,
            // minHeight: 360,
            // background: colorBgContainer,
            // borderRadius: borderRadiusLG,
          }}
            className='unmapped-container'
          >
            <div className="unmapped-header-container">
              <span className="unmapped-down-icon"
                onClick={() => setCollapsed(!collapsed)}
                style={{ cursor: 'pointer' }}
              >
                {collapsed ? <CaretUpFilled /> : <CaretDownFilled />}
              </span>
              <span className="unmapped-header-text">
                {Constants.LABEL_UNMAPPED_CDLS}
              </span>
              <div className="unmapped-export-button">
                <ExportResultsButton constantText={Constants.BUTTON_EXPORT_UNMAPPED} />
              </div>
            </div>
            {!collapsed && (
              <>
                <div className='unmapped-result-text-space'>
                  <span className="unmapped-result-text">
                    {Constants.LABEL_UNMAPPED_CDLS_SELECT_TEXT}
                  </span>
                </div>

                <Table
                  pagination={paginationConfig}
                  size='small'
                  rowSelection={rowSelection}
                  columns={columns}
                  dataSource={filteredData}
                  locale={{
                    emptyText: (
                      <div className='unmapped-table-text'>
                        <span>{Constants.LABEL_UNMAPPED_CDLS_TABLE_NO_UNASSOCIATED_REPERTOIRE_TEXT}</span>
                      </div>
                    )
                  }}
                  className="custom-table-style"
                  scroll={{
                    x: 'max-content'
                  }}
                  rowClassName={getRowClassName}
                >

                </Table>
                {selectedRowsData.length > 0 && (
                  <MapSelectionCDL selectedRows={selectedRowsData} />
                )}
              </>
            )}
          </div>

          <div style={{ padding: 24 }} className='unassociated-container'>
            <UnMappedRepertoireTable
              dataSource={dataSourceSample}
              rowSelectionChanged={UnMappedRepertoireRowSelectionChanged}
            />
          </div>

        </Content>
      </div>
    </Layout>
  )
}
