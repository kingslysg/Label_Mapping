
import { Row, Col, Input } from 'antd';
import React, { useState, useEffect } from 'react';
import '../../stylesheet/searchMappings.css';

const UnmappedInternationalCDL = ({ formValues, handleInputChange }) => {
    const [isCountryFilled, setIsCountryFilled] = useState(false);
    const [isCompanyFilled, setIsCompanyFilled] = useState(false);
    const [isDivisionFilled, setIsDivisionFilled] = useState(false);
    const [isLabelFilled, setIsLabelFilled] = useState(false);

    useEffect(() => {
        setIsCountryFilled(!!formValues.i_country);
        setIsCompanyFilled(!!formValues.i_company);
        setIsDivisionFilled(!!formValues.i_division);
        setIsLabelFilled(!!formValues.i_label);
    }, [formValues]);

    return (
        <div className='search-cdl'>
            <Row gutter={[10, 10]}> {/* gutter spacing between columns */}

                {/* Country Input */}
                <Col className='search-input-country search-col-style-attributes-unmapped'>
                    {isCountryFilled && (
                        <span className="searchfield-text-style">
                            Country
                        </span>
                    )}
                    <Input
                        placeholder="Input Country"
                        allowClear
                        value={formValues.i_country}
                        onChange={(e) => handleInputChange('i_country', e.target.value)}
                        className="search-field-input-style custom-disabled-input"
                        disabled
                    />
                </Col>

                {/* Company Input */}
                <Col className='unmapped-search-input search-col-style-attributes-unmapped'>
                    {isCompanyFilled && (
                        <span className="searchfield-text-style">
                            Company
                        </span>
                    )}
                    <Input
                        placeholder="Input Company"
                        allowClear
                        value={formValues.i_company}
                        onChange={(e) => handleInputChange('i_company', e.target.value)}
                        className="search-field-input-style"
                    />
                </Col>

                {/* Division Input */}
                <Col className='unmapped-search-input search-col-style-attributes-unmapped'>
                    {isDivisionFilled && (
                        <span className="searchfield-text-style">
                            Division
                        </span>
                    )}
                    <Input
                        placeholder="Input Division"
                        allowClear
                        value={formValues.i_division}
                        onChange={(e) => handleInputChange('i_division', e.target.value)}
                        className="search-field-input-style"
                    />
                </Col>

                {/* Label Input */}
                <Col className='unmapped-search-input search-col-style-attributes-unmapped'>
                    {isLabelFilled && (
                        <span className="searchfield-text-style">
                            Label
                        </span>
                    )}
                    <Input
                        placeholder="Input Label"
                        allowClear
                        value={formValues.i_label}
                        onChange={(e) => handleInputChange('i_label', e.target.value)}
                        className="search-field-input-style"
                    />
                </Col>

            </Row>
        </div>
    );
}
export default UnmappedInternationalCDL;