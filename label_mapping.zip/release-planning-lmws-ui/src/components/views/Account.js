import React, { useState } from 'react';
import {
  DesktopOutlined,
  FileOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Breadcrumb, Layout, Menu, theme} from 'antd';



export default function AccountPage() {
      const {
        token: { colorBgContainer, borderRadiusLG },
      } = theme.useToken();
      const { Content, Footer, Sider } = Layout;
    return (
                <Layout className='layout-panel'>
                    <Content className='content-style'>

                        <Breadcrumb className='breadcrumb-style'>
                            <Breadcrumb.Item>CDL</Breadcrumb.Item>
                            <Breadcrumb.Item>Account</Breadcrumb.Item>
                        </Breadcrumb>

                        <div  style={{
                            padding: 24,
                            minHeight: 360,
                            background: colorBgContainer,
                            borderRadius: borderRadiusLG,
                            }}
                        >
                            Account page is in-progress.
                        </div>
                    </Content>
                </Layout>          
    ) 
  }
  