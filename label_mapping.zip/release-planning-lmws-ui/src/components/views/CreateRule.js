import React, { useState } from 'react';
import { Breadcrumb, Layout, theme, Row, Col, Input } from 'antd';
import * as Constants from '../util/constants';
import DomesticCDL from './create-rule/new-rule/domesticCDL';
import InternationalCDL from './create-rule/new-rule/internationalCDL';
import CreateNewRuleButton from '../buttons/CreateNewRuleButton';
import ExistingRules from './create-rule/existing-rule/ExistingRules';



export default function SearchMappings() {
  const { token: { colorBgContainer, borderRadiusLG } } = theme.useToken();
  const { Content } = Layout;

  // State to manage input fields
  const [formValues, setFormValues] = useState({
    d_country: '',
    d_family: '',
    d_company: '',
    d_division: '',
    d_label: '',
    d_artist: '',
    d_project: '',
    i_country: '',
    i_company: '',
    i_division: '',
    i_label: ''
  });

  // State to manage search button disabled status
  const [isSearchDisabled, setIsSearchDisabled] = useState(true); // Default disabled

  // Handle input change
  const handleInputChange = (field, value) => {
    const updatedValues = {
      ...formValues,
      [field]: value
    };

    setFormValues(updatedValues);

    // Check if any input field has a value to enable the search button
    //const isAnyFieldFilled = Object.values(updatedValues).some(val => val.trim() !== '');
	const isAnyFieldFilled = (updatedValues.d_country !== '' && updatedValues.i_country !== '');
    setIsSearchDisabled(!isAnyFieldFilled); // Disable if all fields are empty
  };

  // Reset function to clear inputs and disable search button
  const handleReset = () => {
    setFormValues({
      d_country: '',
      d_family: '',
      d_company: '',
      d_division: '',
      d_label: '',
      d_artist: '',
      d_project: '',
      i_country: '',
      i_company: '',
      i_division: '',
      i_label: ''
    });
    setIsSearchDisabled(true); // Disable search button after reset
  };

  // Reset function to clear inputs and disable search button
  const handleSearch = () => {
    /*alert("comming soon => country=" + formValues.d_country +
      "&d_family=" + formValues.d_family +
      "&d_company=" + formValues.d_company +
      "&d_division=" + formValues.d_division +
      "&d_label=" + formValues.d_label +
      "&d_artist=" + formValues.d_artist +
      "&d_project=" + formValues.d_project +
      "&i_country=" + formValues.i_country +
      "&i_company=" + formValues.i_company +
      "&i_division=" + formValues.i_division +
      "&i_label=" + formValues.i_label
    );*/
  };

  return (

    <Layout className='layout-panel'>
      <Content className='content-style' >
          <div className="style-criteria-container">
            <span className="search-home-header">{Constants.LABEL_RULE_MANAGEMENT}</span>
            <span className='search-label-mapping'>  {Constants.LABEL_CREATE_NEW_RULE}</span>

            <div className="create-new-rule-header">
              <span>{Constants.LABEL_CREATE_NEW_RULE_HEADER_TEXT}</span>
            </div>

            <div className='search-cdl'>
              <span className='search-label'>  {Constants.LABEL_DOMESTIC_CDL}</span>
            </div>



            <DomesticCDL
              formValues={formValues}
              handleInputChange={handleInputChange} />

            <div class="create-rule-maps-to">
              MAPS TO
            </div>


            <div className='search-cdl'>
              <span className='search-label'>  {Constants.LABEL_INTERNATIONAL_CDL}</span>
            </div>
            <InternationalCDL
              formValues={formValues}
              handleInputChange={handleInputChange} />

            <div className='div-search-button'>
              <CreateNewRuleButton disableRest={isSearchDisabled}
                disableSearch={isSearchDisabled}
                onResetClick={handleReset}
                onSearchclick={handleSearch}
              >{Constants.LABEL_INTERNATIONAL_CDL}
              </CreateNewRuleButton>
            </div>

          </div>

      {/*Existing Rules cdl */}
    
        <ExistingRules />
      </Content>
    </Layout>


  )

}
