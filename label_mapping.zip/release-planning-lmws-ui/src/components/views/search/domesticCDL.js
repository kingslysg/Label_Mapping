import { Row, Col, Input } from 'antd'; 
import React, { useState, useEffect } from 'react'; 
import '../../stylesheet/searchMappings.css';

export default function DomesticCDL({ formValues, handleInputChange, formValueDisabled }) {
    const [isCountryFilled, setIsCountryFilled] = useState(false);
    const [isFamilyFilled, setIsFamilyFilled] = useState(false);
    const [isCompanyFilled, setIsCompanyFilled] = useState(false);
    const [isDivisionFilled, setIsDivisionFilled] = useState(false);
    const [isLabelFilled, setIsLabelFilled] = useState(false);
    const [isArtistFilled, setIsArtistFilled] = useState(false);
    const [isProjectFilled, setIsProjectFilled] = useState(false);

    useEffect(() => {
        setIsCountryFilled(!!formValues.d_country);
        setIsFamilyFilled(!!formValues.d_family);
        setIsCompanyFilled(!!formValues.d_company);
        setIsDivisionFilled(!!formValues.d_division);
        setIsLabelFilled(!!formValues.d_label);
        setIsArtistFilled(!!formValues.d_artist);
        setIsProjectFilled(!!formValues.d_project);
    }, [formValues]);

    return (
        <div className='search-cdl'>
            <Row gutter={[10, 10]}>
                
                {/* Country Input */}
                <Col className='search-input-country search-col-style-attributes'>
                    {isCountryFilled && (
                        <span className="searchfield-text-style">
                            Country
                        </span>
                    )}
                    <Input
                        placeholder="Input Country"
                        allowClear
                        value={formValues.d_country}
                        onChange={(e) => handleInputChange('d_country', e.target.value)}
                        className="search-field-input-style" 
                        disabled={(formValueDisabled === undefined || formValueDisabled.d_country === undefined) ? 
                                  false : formValueDisabled.d_country}
                    />
                </Col>

                {/* Family Input */}
                <Col className='search-input search-col-style-attributes'>
                    {isFamilyFilled && (
                        <span className="searchfield-text-style">
                            Family
                        </span>
                    )}
                    <Input
                        placeholder="Input Family"
                        allowClear
                        value={formValues.d_family}
                        onChange={(e) => handleInputChange('d_family', e.target.value)}
                        className="search-field-input-style" 
                    />
                </Col>

                {/* Company Input */}
                <Col className='search-input search-col-style-attributes'>
                    {isCompanyFilled && (
                        <span className="searchfield-text-style">
                            Company
                        </span>
                    )}
                    <Input
                        placeholder="Input Company"
                        allowClear
                        value={formValues.d_company}
                        onChange={(e) => handleInputChange('d_company', e.target.value)}
                        className="search-field-input-style" 
                    />
                </Col>

                {/* Division Input */}
                <Col className='search-input search-col-style-attributes'>
                    {isDivisionFilled && (
                        <span className="searchfield-text-style">
                            Division
                        </span>
                    )}
                    <Input
                        placeholder="Input Division"
                        allowClear
                        value={formValues.d_division}
                        onChange={(e) => handleInputChange('d_division', e.target.value)}
                        className="search-field-input-style" 
                    />
                </Col>

                {/* Label Input */}
                <Col className='search-input search-col-style-attributes'>
                    {isLabelFilled && (
                        <span className="searchfield-text-style">
                            Label
                        </span>
                    )}
                    <Input
                        placeholder="Input Label"
                        allowClear
                        value={formValues.d_label}
                        onChange={(e) => handleInputChange('d_label', e.target.value)}
                        className="search-field-input-style" 
                    />
                </Col>

                {/* Artist Input */}
                <Col className='search-input search-col-style-attributes'>
                    {isArtistFilled && (
                        <span className="searchfield-text-style">
                            Artist
                        </span>
                    )}
                    <Input
                        placeholder="Input Artist"
                        allowClear
                        value={formValues.d_artist}
                        onChange={(e) => handleInputChange('d_artist', e.target.value)}
                        className="search-field-input-style" 
                    />
                </Col>

                {/* Project Input */}
                <Col className='search-input search-col-style-attributes'>
                    {isProjectFilled && (
                        <span className="searchfield-text-style">
                            Project
                        </span>
                    )}
                    <Input
                        placeholder="Input Project"
                        allowClear
                        value={formValues.d_project}
                        onChange={(e) => handleInputChange('d_project', e.target.value)}
                        className="search-field-input-style" 
                    />
                </Col>

            </Row>
        </div>
    );
}
