import React, { useState, useEffect } from "react";
import { Row, Col, AutoComplete, Input } from "antd";
import * as Constants from "../../../util/constants";

const testFamilyOptions = [
    { value: "Family A" },
    { value: "Family B" },
    { value: "Family C" },
    { value: "Family D" },
];

const testCompanyOptions = [
    { value: "Company A" },
    { value: "Company B" },
    { value: "Company C" },
    { value: "Company D" },
];

const testDivisionOptions = [
    { value: "Division A" },
    { value: "Division B" },
    { value: "Division C" },
    { value: "Division D" },
];

const testLabelOptions = [
    { value: "Label A" },
    { value: "Label B" },
    { value: "Label C" },
    { value: "Label D" },
];

const testArtistOptions = [
    { value: "Artist A" },
    { value: "Artist B" },
    { value: "Artist C" },
    { value: "Artist D" },
];

const testProjectOptions = [
    { value: "Project A" },
    { value: "Project B" },
    { value: "Project C" },
    { value: "Project D" },
];

const DetailItem = ({ label, value }) => (
    <div className="detail-item">
        <span className="domestic-cdl-header-label">{label}:</span>
        <span className="domestic-cdl-value-label">{value}</span>
    </div>
);

const RuleMappingDomesticCDL = ({
    isEditing,
    domCountry,
    domFamily,
    domCompany,
    domDivision,
    domLabel,
    domArtist, 
    domProject, 
    setDomCountry,
    setDomFamily,
    setDomCompany,
    setDomDivision,
    setDomLabel,
    setDomArtist, 
    setDomProject, 
    onExitEditMode,
}) => {
    const [tempCountry, setTempCountry] = useState(domCountry);
    const [tempFamily, setTempFamily] = useState(domFamily);
    const [tempCompany, setTempCompany] = useState(domCompany);
    const [tempDivision, setTempDivision] = useState(domDivision);
    const [tempLabel, setTempLabel] = useState(domLabel);
    const [tempArtist, setTempArtist] = useState(domArtist); 
    const [tempProject, setTempProject] = useState(domProject); 

    useEffect(() => {
        setDomCountry(tempCountry);
        setDomFamily(tempFamily);
        setDomCompany(tempCompany);
        setDomDivision(tempDivision);
        setDomLabel(tempLabel);
        setDomArtist(tempArtist); 
        setDomProject(tempProject); 
    }, [tempCountry, tempFamily, tempCompany, tempDivision, tempLabel, tempArtist, tempProject]);

    const handleSave = () => {
        setDomCountry(tempCountry);
        setDomFamily(tempFamily);
        setDomCompany(tempCompany);
        setDomDivision(tempDivision);
        setDomLabel(tempLabel);
        setDomArtist(tempArtist); 
        setDomProject(tempProject); 
        onExitEditMode();
    };

    return (
        <div className="domestic-section">
            <h3 className="view-cdl-header">{Constants.LABEL_DOMESTIC_CDL}</h3>
            <div
                className={`edit-domestic-cdl-mapping-viewMode ${
                    isEditing ? "edit-domestic-cdl-mapping-viewMode-hidden" : ""
                }`}
            >
                <div className="section-content">
                    <DetailItem label="Country" value={domCountry} />
                    <DetailItem label="Family" value={domFamily} />
                    <DetailItem label="Company" value={domCompany} />
                    <DetailItem label="Division" value={domDivision} />
                    <DetailItem label="Label" value={domLabel} />
                    <DetailItem label="Artist" value={domArtist} />
                    <DetailItem label="Project" value={domProject} />
                </div>
            </div>

            {isEditing ? (
                <Row gutter={[10, 10]}>
                    <Col className="edit-cdl-input edit-col-style-attributes non-editable">
                        {tempCountry && <span className="edit-text-style">{Constants.COUNTRY}</span>}
                        <Input
                            placeholder="Input Country"
                            allowClear
                            value={tempCountry}
                            onChange={(e) => setTempCountry(e.target.value)}
                            className="edit-cdl-input-style"
                            readOnly={true}
                        />
                    </Col>
                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempFamily && <span className="edit-text-style">{Constants.FAMILY}</span>}
                        <AutoComplete
                            options={testFamilyOptions}
                            placeholder="Input Family"
                            value={tempFamily}
                            allowClear={!!tempFamily}
                            onChange={(value) => setTempFamily(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>
                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempCompany && <span className="edit-text-style">{Constants.COMPANY}</span>}
                        <AutoComplete
                            options={testCompanyOptions}
                            placeholder="Input Company"
                            value={tempCompany}
                            allowClear={!!tempCompany}
                            onChange={(value) => setTempCompany(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>
                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempDivision && <span className="edit-text-style">{Constants.DIVISION}</span>}
                        <AutoComplete
                            options={testDivisionOptions}
                            placeholder="Input Division"
                            value={tempDivision}
                            allowClear={!!tempDivision}
                            onChange={(value) => setTempDivision(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>
                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempLabel && <span className="edit-text-style">{Constants.LABEL}</span>}
                        <AutoComplete
                            options={testLabelOptions}
                            placeholder="Input Label"
                            value={tempLabel}
                            allowClear={!!tempLabel}
                            onChange={(value) => setTempLabel(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>
                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempArtist && <span className="edit-text-style">{Constants.ARTIST}</span>}
                        <AutoComplete
                            options={testArtistOptions}
                            placeholder="Input Artist"
                            value={tempArtist}
                            allowClear={!!tempArtist}
                            onChange={(value) => setTempArtist(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>
                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempProject && <span className="edit-text-style">{Constants.PROJECT}</span>}
                        <AutoComplete
                            options={testProjectOptions}
                            placeholder="Input Project"
                            value={tempProject}
                            allowClear={!!tempProject}
                            onChange={(value) => setTempProject(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>
                </Row>
            ) : null}
        </div>
    );
};

export default RuleMappingDomesticCDL;
