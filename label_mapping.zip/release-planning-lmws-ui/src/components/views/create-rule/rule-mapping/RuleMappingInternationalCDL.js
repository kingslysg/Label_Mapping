import React, { useState, useEffect } from "react";
import { Row, Col, AutoComplete } from "antd";
import * as Constants from "../../../util/constants";

// Test Data for AutoComplete
const testCountryOptions = [
    { value: "Country A" },
    { value: "Country B" },
    { value: "Country C" },
    { value: "Country D" },
];

const testCompanyOptions = [
    { value: "Company A" },
    { value: "Company B" },
    { value: "Company C" },
    { value: "Company D" },
];

const testDivisionOptions = [
    { value: "Division A" },
    { value: "Division B" },
    { value: "Division C" },
    { value: "Division D" },
];

const testLabelOptions = [
    { value: "Label A" },
    { value: "Label B" },
    { value: "Label C" },
    { value: "Label D" },
];

const DetailItem = ({ label, value }) => (
    <div className="detail-item">
        <span className="domestic-cdl-header-label">{label}:</span>
        <span className="domestic-cdl-value-label">{value}</span>
    </div>
);

const RuleMappingInternationalCDL = ({
    isEditing,
    intlCountry,
    intlCompany,
    intlDivision,
    intlLabel,
    setIntlCountry,
    setIntlCompany,
    setIntlDivision,
    setIntlLabel,
}) => {
    const [tempCountry, setTempCountry] = useState(intlCountry);
    const [tempCompany, setTempCompany] = useState(intlCompany);
    const [tempDivision, setTempDivision] = useState(intlDivision);
    const [tempLabel, setTempLabel] = useState(intlLabel);

    /*
    useEffect(() => {
        setTempCountry(intlCountry);
        setTempCompany(intlCompany);
        setTempDivision(intlDivision);
        setTempLabel(intlLabel);
    }, [intlCountry, intlCompany, intlDivision, intlLabel]);
    */

    useEffect(() => {
        setIntlCountry(tempCountry);
        setIntlCompany(tempCompany);
        setIntlDivision(tempDivision);
        setIntlLabel(tempLabel);
        //alert('rule-Intl'); 
    }, [tempCountry, tempCompany, tempDivision, tempLabel]);

    const handleSave = () => {
        setIntlCountry(tempCountry);
        setIntlCompany(tempCompany);
        setIntlDivision(tempDivision);
        setIntlLabel(tempLabel);
    };

    const handleCountryClear = () => {
        setTempCountry("");
        setTempCompany("");
        setTempDivision("");
        setTempLabel("");
    };

    return (
        <div className="edit-international-cdl-mapping international-section">
            <h3 className="view-cdl-header">{Constants.LABEL_INTERNATIONAL_CDL}</h3>
            <div className={isEditing ? "viewMode hidden" : "viewMode visible"}>
                <div className="section-content">
                    <DetailItem label="Country" value={intlCountry} />
                    <DetailItem label="Company" value={intlCompany} />
                    <DetailItem label="Division" value={intlDivision} />
                    <DetailItem label="Label" value={intlLabel} />
                </div>
            </div>

            {isEditing ? (
                <Row gutter={[10, 10]}>
                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempCountry && <span className="edit-text-style">{Constants.COUNTRY}</span>}
                        <AutoComplete
                            options={testCountryOptions}
                            placeholder="Input Country"
                            value={tempCountry}
                            allowClear
                            onChange={(value) => setTempCountry(value)}
                            onClear={handleCountryClear}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>

                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempCompany && <span className="edit-text-style">{Constants.COMPANY}</span>}
                        <AutoComplete
                            options={testCompanyOptions}
                            placeholder="Input Company"
                            value={tempCompany}
                            allowClear
                            onChange={(value) => setTempCompany(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>

                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempDivision && <span className="edit-text-style">{Constants.DIVISION}</span>}
                        <AutoComplete
                            options={testDivisionOptions}
                            placeholder="Input Division"
                            value={tempDivision}
                            allowClear
                            onChange={(value) => setTempDivision(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>

                    <Col className="edit-cdl-input edit-col-style-attributes">
                        {tempLabel && <span className="edit-text-style">{Constants.LABEL}</span>}
                        <AutoComplete
                            options={testLabelOptions}
                            placeholder="Input Label"
                            value={tempLabel}
                            allowClear
                            onChange={(value) => setTempLabel(value)}
                            className="edit-cdl-input-style custom-autocomplete"
                        />
                    </Col>
                </Row>
            ) : null}
        </div>
    );
};

export default RuleMappingInternationalCDL;
