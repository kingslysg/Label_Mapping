import React from "react";
import { Button } from "antd";
import * as Constants from "../../../util/constants";

export const CancelButton = ({ onCancel }) => (
    <Button onClick={onCancel} className='defaultButtonStyle'>
        {Constants.BUTTON_CANCEL}
    </Button>
);

export const SaveButton = ({ onSave, disabled }) => (
    <Button
        type="primary"
        onClick={onSave}
        className='selectedButtonStyle'
        disabled={disabled}
    >
        {Constants.BUTTON_SAVE}
    </Button>
);

const CloseButton = ({ onClose }) => (
    <Button onClick={onClose} className='defaultButtonStyle'>
        {Constants.BUTTON_CLOSE}
    </Button>
);

const EditButton = ({ onEdit }) => (
    <Button type="primary" onClick={onEdit} className='selectedButtonStyle'>
        {Constants.BUTTON_EDIT}
    </Button>
);

const DeleteButton = ({ onEdit }) => (
    <Button className='selectedButtonStyle deleteButtonStyle'>
        {Constants.BUTTON_DELETE}
    </Button>
);

const RuleMappingControlButtons = ({ onClose, onEdit, onCancel, onSave, isEditing, isSaveDisabled }) => (
    <div className="footer-buttons">
        {!isEditing && (
            <div className="viewMode">
                <DeleteButton onEdit={onEdit} />
                <CloseButton onClose={onClose} />&nbsp;&nbsp;
                <EditButton onEdit={onEdit} />
            </div>
        )}

        
    </div>
);

export default RuleMappingControlButtons;
