import React, { useState, useEffect } from "react";
import { Modal } from "antd";
import { InfoCircleOutlined, ExclamationCircleOutlined } from "@ant-design/icons";

import CdlMappingFooterButtons, { CancelButton, SaveButton } from "./RuleMappingControlButtons";

import RuleMappingDomesticCDL from "./RuleMappingDomesticCDL";
import RuleMappingInternationalCDL from "./RuleMappingInternationalCDL";
import * as Constants from "../../../util/constants";
import CustomCloseImageMappingCDL from "../../../images/svg-components/CustomCloseImageMappingCDL";
import CustomVerificationCheckBoxImageMappingCDL from "../../../images/svg-components/CustomVerificationCheckBoxImageMappingCDL";

const ModalCreateRuleDetails = ({ isVisible, onClose, selectedData = {} }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [showMessage, setShowMessage] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  // Current state for domestic fields
  const [domCountry, setDomCountry] = useState(selectedData.domCountry || "");
  const [domFamily, setDomFamily] = useState(selectedData.domFamily || "");
  const [domCompany, setDomCompany] = useState(selectedData.domCompany || "");
  const [domDivision, setDomDivision] = useState(selectedData.domDivision || "");
  const [domLabel, setDomLabel] = useState(selectedData.domLabel || "");
  const [domArtist, setDomArtist] = useState(selectedData.domArtist || "");
  const [domProject, setDomProject] = useState(selectedData.domProject || ""); 

  // Current state for international fields
  const [intlCountry, setIntlCountry] = useState(selectedData.intlCountry || "");
  const [intlCompany, setIntlCompany] = useState(selectedData.intlCompany || "");
  const [intlDivision, setIntlDivision] = useState(selectedData.intlDivision || "");
  const [intlLabel, setIntlLabel] = useState(selectedData.intlLabel || "");

  // Saved state for domestic fields
  const [savedDataVauleOfDomCountry, setSavedDataVauleOfDomCountry] = useState(selectedData.domCountry || "");
  const [savedDataVauleOfDomFamily, setSavedDataVauleOfDomFamily] = useState(selectedData.domFamily || "");
  const [savedDataVauleOfDomCompany, setSavedDataVauleOfDomCompany] = useState(selectedData.domCompany || "");
  const [savedDataVauleOfDomDivision, setSavedDataVauleOfDomDivision] = useState(selectedData.domDivision || "");
  const [savedDataVauleOfDomLabel, setSavedDataVauleOfDomLabel] = useState(selectedData.domLabel || "");
  const [savedDataVauleOfDomArtist, setSavedDataVauleOfDomArtist] = useState(selectedData.domArtist || "");
  const [savedDataVauleOfDomProject, setSavedDataVauleOfDomProject] = useState(selectedData.domProject || "");

  // Saved state for international fields
  const [savedDataVauleOfIntlCountry, setSavedDataVauleOfIntlCountry] = useState(selectedData.intlCountry || "");
  const [savedDataVauleOfIntlCompany, setSavedDataVauleOfIntlCompany] = useState(selectedData.intlCompany || "");
  const [savedDataVauleOfIntlDivision, setSavedDataVauleOfIntlDivision] = useState(selectedData.intlDivision || "");
  const [savedDataVauleOfIntlLabel, setSavedDataVauleOfIntlLabel] = useState(selectedData.intlLabel || "");

  const toggleEditMode = () => {
    setIsEditing(!isEditing);
    setShowMessage(false);
    setHasChanges(false);

    // Reset fields to saved state when toggling edit mode
    setDomCountry(savedDataVauleOfDomCountry);
    setDomFamily(savedDataVauleOfDomFamily);
    setDomCompany(savedDataVauleOfDomCompany);
    setDomDivision(savedDataVauleOfDomDivision);
    setDomLabel(savedDataVauleOfDomLabel);
    setDomArtist(savedDataVauleOfDomArtist);
    setDomProject(savedDataVauleOfDomProject); 

    setIntlCountry(savedDataVauleOfIntlCountry);
    setIntlCompany(savedDataVauleOfIntlCompany);
    setIntlDivision(savedDataVauleOfIntlDivision);
    setIntlLabel(savedDataVauleOfIntlLabel);
  };

  const onSaveClick = () => {
    // Save current values into saved states
    setSavedDataVauleOfDomCountry(domCountry);
    setSavedDataVauleOfDomFamily(domFamily);
    setSavedDataVauleOfDomCompany(domCompany);
    setSavedDataVauleOfDomDivision(domDivision);
    setSavedDataVauleOfDomLabel(domLabel);
    setSavedDataVauleOfDomArtist(domArtist);
    setSavedDataVauleOfDomProject(domProject); 

    setSavedDataVauleOfIntlCountry(intlCountry);
    setSavedDataVauleOfIntlCompany(intlCompany);
    setSavedDataVauleOfIntlDivision(intlDivision);
    setSavedDataVauleOfIntlLabel(intlLabel);

    setIsEditing(false);
    setShowMessage(true);
    setHasChanges(false);
  };

  const onCancelClick = () => {
    // Reset fields to last saved state
    setDomCountry(savedDataVauleOfDomCountry);
    setDomFamily(savedDataVauleOfDomFamily);
    setDomCompany(savedDataVauleOfDomCompany);
    setDomDivision(savedDataVauleOfDomDivision);
    setDomLabel(savedDataVauleOfDomLabel);
    setDomArtist(savedDataVauleOfDomArtist);
    setDomProject(savedDataVauleOfDomProject); 

    setIntlCountry(savedDataVauleOfIntlCountry);
    setIntlCompany(savedDataVauleOfIntlCompany);
    setIntlDivision(savedDataVauleOfIntlDivision);
    setIntlLabel(savedDataVauleOfIntlLabel);

    // Exit edit mode
    setIsEditing(false);

    // Reset any UI flags for messaging
    setShowMessage(false);
    setHasChanges(false);
  };

  const checkForChanges = () => {
    const isDomesticChanged =
      savedDataVauleOfDomCountry !== domCountry ||
      savedDataVauleOfDomFamily !== domFamily ||
      savedDataVauleOfDomCompany !== domCompany ||
      savedDataVauleOfDomDivision !== domDivision ||
      savedDataVauleOfDomLabel !== domLabel ||
      savedDataVauleOfDomArtist !== domArtist ||
      savedDataVauleOfDomProject !== domProject; 

    const isInternationalChanged =
      savedDataVauleOfIntlCountry !== intlCountry ||
      savedDataVauleOfIntlCompany !== intlCompany ||
      savedDataVauleOfIntlDivision !== intlDivision ||
      savedDataVauleOfIntlLabel !== intlLabel;

    setHasChanges(isDomesticChanged || isInternationalChanged);
  };

  useEffect(() => {
    if (isEditing) {
      checkForChanges();
    }
  }, [domCountry, domFamily, domCompany, domDivision, domLabel, domArtist, domProject, intlCountry, intlCompany, intlDivision, intlLabel]);

  return (
    <Modal
      width='110%'
      title={
        <div>
          {showMessage && (
            <div className="modal-save-success-message-container">
              <table className="modal-save-success-message-table">
                <tr>
                  <td align="center">
                    <span>
                      <CustomVerificationCheckBoxImageMappingCDL />
                      <span className="rule-create-success">
                        {Constants.RULE_CREATE_SUCCESS}
                      </span>
                    </span>
                  </td>
                  <td align="right">
                    <span>
                      <CustomCloseImageMappingCDL onClick={() => setShowMessage(false)} />
                    </span>
                  </td>
                </tr>
              </table>
            </div>
          )}
          <span className="modal-title">
            {isEditing ? (
              <ExclamationCircleOutlined className="exclamation-editmode-outline" />
            ) : (
              <InfoCircleOutlined className="exclamation-viewmode-outline" />
            )}
            {isEditing ? (
              <div className="editMode">
                {Constants.LABEL_EDIT_RULE_DETAIL}
              </div>
            ) : (
              <div className="viewMode">
                <label className="view-CDL-label">
                  {Constants.LABEL_VIEW_RULE_DETAILS}
                </label>
              </div>
            )}
          </span>
          <div>
            {isEditing ? (
              <div className="edit-create-rule-mode-style">
                {Constants.LABEL_EDIT_CDL_CREATE_RULE_TEXT}
              </div>
            ) : (
              <div />
            )}
          </div>
        </div>
      }
      visible={isVisible}
      onCancel={onClose}
      footer={
        <CdlMappingFooterButtons
          onClose={onClose}
          onEdit={toggleEditMode}
          onCancel={onCancelClick}
          onSave={onSaveClick}
          isEditing={isEditing}
          isSaveDisabled={!hasChanges}
        />
      }
      closeIcon={null}
    >
      <section
        className={`rules-employed-container ${isEditing ? "editing-mode" : "view-mode"
          }`}
      >
        <RuleMappingDomesticCDL
          isEditing={isEditing}
          domCountry={domCountry}
          domFamily={domFamily}
          domCompany={domCompany}
          domDivision={domDivision}
          domLabel={domLabel}
          domArtist={domArtist}
          domProject={domProject} 
          setDomCountry={setDomCountry}
          setDomFamily={setDomFamily}
          setDomCompany={setDomCompany}
          setDomDivision={setDomDivision}
          setDomLabel={setDomLabel}
          setDomArtist={setDomArtist}
          setDomProject={setDomProject} 
        />
        <div className="maps-to-text-inside-edit-section">
          {Constants.LABEL_MAPS_TO}
        </div>
        <RuleMappingInternationalCDL
          isEditing={isEditing}
          intlCountry={intlCountry}
          intlCompany={intlCompany}
          intlDivision={intlDivision}
          intlLabel={intlLabel}
          setIntlCountry={setIntlCountry}
          setIntlCompany={setIntlCompany}
          setIntlDivision={setIntlDivision}
          setIntlLabel={setIntlLabel}
        />

        {isEditing && (
          <div className="footer-buttons edit-mode-buttons">
            <CancelButton onCancel={onCancelClick} />
            <SaveButton onSave={onSaveClick} disabled={!hasChanges} />
          </div>
        )}
      </section>
    </Modal>
  );
};

export default ModalCreateRuleDetails;
