import { Layout, Table, Checkbox, Input } from "antd";
import { Content } from "antd/es/layout/layout";
import { CaretDownFilled } from "@ant-design/icons";
import { useRef } from "react";
import * as Constants from "../../../util/constants";
import ExistingRuleControlButtons, { useFilterActions } from "../../../buttons/ExistingRuleControlButtons";
import { ExportResultsButton } from "../../../buttons/ExportButton";
import CDLMappingDetailsModal from "../../cdl-mapping-details/ModalCdlMappingDetails"


const PaginationConfig = (filteredData) => ({
    pageSize: 10, 
    disabled: filteredData.length <= 10, 
    showSizeChanger: false,
});

export default function ExistingRules() {
    const inputRef = useRef(null);

    const dataSource = [
        {
            key: "1",
            domCountry: "US",
            domFamily: "IGA",
            domCompany: "21 Entertainment",
            domDivision: "21 Entertainment",
            domLabel: "Universal Prod label",
            domArtist: "Artist A",
            intlCountry: "DE",
            intlCompany: "Universal Production Music GmbH",
            intlDivision: "Universal Production",
            intlLabel: "Universal Prod label",
            dateOfEntry: "01 Oct 2024",
        },
        {
            key: "2",
            domCountry: "DE",
            domFamily: "UMPG",
            domCompany: "Universal Music Group Germany 1",
            domDivision: "UMG Division 1",
            domLabel: "Universal Germany label",
            domArtist: "Artist B",
            intlCountry: "FR",
            intlCompany: "Universal Music Germany",
            intlDivision: "Universal Germany",
            intlLabel: "Universal Germany label",
            dateOfEntry: "10 Oct 2024",
        },
        {
            key: "3",
            domCountry: "DE",
            domFamily: "UMG",
            domCompany: "Universal Music Group Germany",
            domDivision: "UMG Division",
            domLabel: "Universal France label",
            domArtist: "Artist C",
            intlCountry: "FR",
            intlCompany: "Universal Music France",
            intlDivision: "Universal France",
            intlLabel: "Universal France label",
            dateOfEntry: "15 Oct 2024",
        },
        {
            key: "4",
            domCountry: "FR",
            domFamily: "UMF",
            domCompany: "Universal Music France",
            domDivision: "UMF Division",
            domLabel: "UMG Division label",
            domArtist: "Artist D",
            intlCountry: "DE",
            intlCompany: "Universal Music Germany",
            intlDivision: "UMG Division",
            intlLabel: "UMG Division label",
            dateOfEntry: "20 Oct 2024",
        },
        {
            key: "5",
            domCountry: "IT",
            domFamily: "UMG Italy",
            domCompany: "Universal Music Italy",
            domDivision: "Music Division",
            domLabel: "UMG USA label",
            domArtist: "Artist E",
            intlCountry: "US",
            intlCompany: "Universal Music Group USA",
            intlDivision: "UMG USA Division",
            intlLabel: "UMG USA label",
            dateOfEntry: "25 Oct 2024",
        },
        {
            key: "6",
            domCountry: "IT",
            domFamily: "Music Publishing",
            domCompany: "Italy Music Publishing",
            domDivision: "Publishing Division",
            domLabel: "UMG UK label",
            domArtist: "Artist F",
            intlCountry: "UK",
            intlCompany: "Universal Music UK",
            intlDivision: "UMG UK Division",
            intlLabel: "UMG UK label",
            dateOfEntry: "30 Oct 2024",
        },
        {
            key: "7",
            domCountry: "IT",
            domFamily: "Sony Italy",
            domCompany: "Sony Music Italy",
            domDivision: "Sony Division",
            domLabel: "Japan Division label",
            domArtist: "Artist G",
            intlCountry: "JP",
            intlCompany: "Sony Music Japan",
            intlDivision: "Japan Division",
            intlLabel: "Japan Division label",
            dateOfEntry: "05 Nov 2024",
        },
        {
            key: "8",
            domCountry: "UK",
            domFamily: "Universal UK",
            domCompany: "Universal Music UK",
            domDivision: "UK Division 1",
            domLabel: "UMG UK label",
            domArtist: "Artist H",
            intlCountry: "US",
            intlCompany: "Universal Music Group USA",
            intlDivision: "UMG USA Division",
            intlLabel: "UMG UK label",
            dateOfEntry: "10 Nov 2024",
        },
        {
            key: "9",
            domCountry: "UK",
            domFamily: "Sony UK",
            domCompany: "Sony Music UK",
            domDivision: "Sony UK Division",
            domLabel: "Universal France label",
            domArtist: "Artist I",
            intlCountry: "FR",
            intlCompany: "Universal Music France",
            intlDivision: "Universal France Division",
            intlLabel: "Universal France label",
            dateOfEntry: "15 Nov 2024",
        },
        {
            key: "10",
            domCountry: "UK",
            domFamily: "EMI UK",
            domCompany: "EMI Music UK",
            domDivision: "EMI UK Division",
            domLabel: "Germany label",
            domArtist: "Artist J",
            intlCountry: "DE",
            intlCompany: "Universal Music Germany",
            intlDivision: "Germany Division",
            intlLabel: "Germany label",
            dateOfEntry: "20 Nov 2024",
        },
        {
            key: "11",
            domCountry: "AE",
            domFamily: "UMG UAE",
            domCompany: "Universal Music UAE",
            domDivision: "UAE Division 1",
            domLabel: "UMG AE label",
            domArtist: "Artist K",
            intlCountry: "US",
            intlCompany: "Universal Music Group USA",
            intlDivision: "UMG USA Division",
            intlLabel: "UMG AE label",
            dateOfEntry: "25 Nov 2024",
        },
        {
            key: "12",
            domCountry: "AE",
            domFamily: "Sony UAE",
            domCompany: "Sony Music UAE",
            domDivision: "Sony UAE Division",
            domLabel: "Soney Germany label",
            domArtist: "Artist L",
            intlCountry: "FR",
            intlCompany: "Sony Music France",
            intlDivision: "Sony France Division",
            intlLabel: "Soney Germany label",
            dateOfEntry: "30 Nov 2024",
        },
        {
            key: "13",
            domCountry: "AE",
            domFamily: "Family-13",
            domCompany: "Company-13",
            domDivision: "Division-13",
            domLabel: "Label M",
            domArtist: "Artist M",
            intlCountry: "DE",
            intlCompany: "Intl-Company-13",
            intlDivision: "Intl-Division-13",
            intlLabel: "Intl-Label-13",
            dateOfEntry: "05 Dec 2024",
        },
        {
            key: "14",
            domCountry: "AE",
            domFamily: "Family-14",
            domCompany: "Company-14",
            domDivision: "Division-14",
            domLabel: "Label N",
            domArtist: "Artist N",
            intlCountry: "IT",
            intlCompany: "Intl-Company-14",
            intlDivision: "Intl-Division-14",
            intlLabel: "Intl-Label-14",
            dateOfEntry: "10 Dec 2024",
        },
        {
            key: "15",
            domCountry: "AE",
            domFamily: "Family-15",
            domCompany: "Company-15",
            domDivision: "Division-15",
            domLabel: "Label O",
            domArtist: "Artist O",
            intlCountry: "JP",
            intlCompany: "Intl-Company-15",
            intlDivision: "Intl-Division-15",
            intlLabel: "Intl-Label-15",
            dateOfEntry: "15 Dec 2024",
        },
        {
            key: "16",
            domCountry: "AE",
            domFamily: "Family-16",
            domCompany: "Company-16",
            domDivision: "Division-16",
            domLabel: "Label P",
            domArtist: "Artist P",
            intlCountry: "UK",
            intlCompany: "Intl-Company-16",
            intlDivision: "Intl-Division-16",
            intlLabel: "Intl-Label-16",
            dateOfEntry: "20 Dec 2024",
        },
    ];
    
    
    const countries = [
        { label: "United States", value: "US" },
        { label: "Germany", value: "DE" },
        { label: "France", value: "FR" },
        { label: "Italy", value: "IT" },
        { label: "Spain", value: "ES" },
        { label: "Canada", value: "CA" },
        { label: "Australia", value: "AU" },
        { label: "India", value: "IN" },
        { label: "Japan", value: "JP" },
        { label: "China", value: "CN" },
        { label: "Brazil", value: "BR" },
        { label: "Russia", value: "RU" },
        { label: "South Africa", value: "ZA" },
        { label: "United Kingdom", value: "UK" },
        { label: "United Arab Emirates", value: "AE" },
    ];

    const {
        searchText,
        setSearchText,
        selectedFilters,
        setSelectedFilters,
        selectedFiltersOther,
        setSelectedFiltersOther,
        filteredCountries,
        setFilteredCountries,
        filteredData,
        highlightedFilters,
        handleFilterSaveSearch,
        handleFilterSaveSearchOther,
        handleResetButton,
        handleResetButtonOther

    } = useFilterActions(dataSource, countries);

    const getUniqueValues = (dataIndex) => {
        // Get all values for the specified dataIndex from dataSource
        const values = dataSource.map((item) => item[dataIndex]);
        // Use Set to filter unique values, then map them to the required structure
        const uniqueValues = Array.from(new Set(values)).map((value) => ({
            label: value,
            value,
        }));
        return uniqueValues;
    };

    const handleFilterChange = (value) => {
        const updatedFilters = selectedFilters.includes(value)
            ? selectedFilters.filter((filter) => filter !== value)
            : [...selectedFilters, value];
        setSelectedFilters(updatedFilters);
    };

    const handleFilterChangeOther = (dataIndex, value) => {
        setSelectedFiltersOther((prev) => {
            const currentFilters = prev[dataIndex] || [];
            const updatedFilters = currentFilters.includes(value)
                ? currentFilters.filter((filter) => filter !== value)
                : [...currentFilters, value];
            return { ...prev, [dataIndex]: updatedFilters };
        });
    };


    const handleSearchTextChange = (e) => {
        const value = e.target.value;
        setSearchText(value);
        const filtered = countries.filter((country) =>
            country.label.toLowerCase().startsWith(value.toLowerCase())
        );
        setFilteredCountries(filtered);
    };

    const handleSearchTextChangeOther = (value, options) => {
        return options.filter((option) =>
            option.label.toLowerCase().includes(value.toLowerCase())
        );
    };


    const renderFilterDropdown = () => (
        <div className="filter-dropdown-container">
            <div className="filter-dropdown-header">
                <span className="filter-label">Filter:</span>
                <Input
                    ref={inputRef}
                    placeholder="Search"
                    value={searchText}
                    onChange={handleSearchTextChange}
                    className="filter-input"
                />
            </div>
            <div className="filter-checkbox-list">
                {filteredCountries.map((country) => (
                    <Checkbox
                        key={country.value}
                        checked={selectedFilters.includes(country.value)}
                        onChange={() => handleFilterChange(country.value)}
                    >
                        {country.label}
                    </Checkbox>
                ))}
            </div>
            <div className="filter-dropdown-actions">
                <ExistingRuleControlButtons.ResetButton handleClick={
                    handleResetButton
                } />
                <ExistingRuleControlButtons.SaveButton handleClick={
                    handleFilterSaveSearch} />
            </div>
        </div>
    );


    const renderFilterDropdownOther = (dataIndex) => {
        const options = getUniqueValues(dataIndex);
        return (
            <div className="filter-dropdown-container">
                <div className="filter-dropdown-header">
                    <span className="filter-label">Filter:</span>
                    <Input
                        ref={inputRef}
                        placeholder="Search"
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                        className="filter-input"
                    />
                </div>
                <div className="filter-checkbox-list">
                    {handleSearchTextChangeOther(searchText, options).map((option) => (
                        <Checkbox
                            key={option.value}
                            checked={(selectedFiltersOther[dataIndex] || []).includes(option.value)}
                            onChange={() => handleFilterChangeOther(dataIndex, option.value)}
                        >
                            {option.label}
                        </Checkbox>
                    ))}
                </div>
                <div className="filter-dropdown-actions">
                    <ExistingRuleControlButtons.ResetOtherButton handleClick={() =>
                        handleResetButtonOther(dataIndex)} />
                    <ExistingRuleControlButtons.SaveOtherButton handleClick={() =>
                        handleFilterSaveSearchOther(dataIndex)
                    } />
                </div>
            </div>
        )
    };


    const columns = [
        {
            title: <div className="existing-rule-form-header">Domestic Country</div>,
            dataIndex: "domCountry",
            key: "domCountry",
            className: `existing-rule-form-attributes ${highlightedFilters.domCountry ? "highlighted-filter-icon" : ""}`,
            width: 145,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.domCountry.localeCompare(b.domCountry),
            filterDropdown: renderFilterDropdown,
        },
        {
            title: <div className="existing-rule-form-header">Domestic Family</div>,
            dataIndex: "domFamily",
            key: "domFamily",
            className: `existing-rule-form-attributes ${highlightedFilters.domFamily ? "highlighted-filter-icon" : ""}`,
            width: 131,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.domFamily.localeCompare(b.domFamily),
            filterDropdown: () => renderFilterDropdownOther("domFamily"),
        },
        {
            title: <div className="existing-rule-form-header">Domestic<br />Company</div>,
            dataIndex: "domCompany",
            key: "domCompany",
            className: `existing-rule-form-attributes ${highlightedFilters.domCompany ? "highlighted-filter-icon" : ""}`,
            width: 131,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.domCompany.localeCompare(b.domCompany),
            filterDropdown: () => renderFilterDropdownOther("domCompany"),
        },
        {
            title: <div className="existing-rule-form-header">Domestic<br />Division</div>,
            dataIndex: "domDivision",
            key: "domDivision",
            className: `existing-rule-form-attributes ${highlightedFilters.domDivision ? "highlighted-filter-icon" : ""}`,
            width: 131,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.domDivision.localeCompare(b.domDivision),
            filterDropdown: () => renderFilterDropdownOther("domDivision"),
        },
        {
            title: <div className="existing-rule-form-header">Domestic<br />Label</div>,
            dataIndex: "domLabel",
            key: "domLabel",
            className: `existing-rule-form-attributes ${highlightedFilters.domLabel ? "highlighted-filter-icon" : ""}`,
            width: 131,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.domLabel.localeCompare(b.domLabel),
            filterDropdown: () => renderFilterDropdownOther("domLabel"),
        },
        {
            title: <div className="existing-rule-form-header">Domestic Artist</div>,
            dataIndex: "domArtist",
            key: "domArtist",
            className: `existing-rule-form-attributes ${highlightedFilters.domArtist ? "highlighted-filter-icon" : ""}`,
            width: 131,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.domArtist.localeCompare(b.domArtist),
            filterDropdown: () => renderFilterDropdownOther("domArtist"),
        },
        {
            title: <div className="custom-header-style-map custom-value-style-map">MAPS TO</div>,
            key: "mapsTo",
            className: "custom-header-style-map custom-value-style-map",
            width: 50,
            render: () => <span>&gt;&gt;</span>,
        },
        {
            title: <div className="existing-rule-form-header">International Country</div>,
            dataIndex: "intlCountry",
            key: "intlCountry",
            className: `existing-rule-form-attributes ${highlightedFilters.intlCountry ? "highlighted-filter-icon" : ""}`,
            width: 137,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.intlCountry.localeCompare(b.intlCountry),
            filterDropdown: () => renderFilterDropdownOther("intlCountry"),
        },
        {
            title: <div className="existing-rule-form-header">International<br />Company</div>,
            dataIndex: "intlCompany",
            key: "intlCompany",
            width: 131,
            className: `existing-rule-form-attributes ${highlightedFilters.intlCompany ? "highlighted-filter-icon" : ""}`,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.intlCompany.localeCompare(b.intlCompany),
            filterDropdown: () => renderFilterDropdownOther("intlCompany"),
        },
        {
            title: <div className="existing-rule-form-header">International<br />Division</div>,
            dataIndex: "intlDivision",
            key: "intlDivision",
            width: 131,
            className: `existing-rule-form-attributes ${highlightedFilters.intlDivision ? "highlighted-filter-icon" : ""}`,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.intlDivision.localeCompare(b.intlDivision),
            filterDropdown: () => renderFilterDropdownOther("intlDivision"),
        },
        {
            title: <div className="existing-rule-form-header">International<br />Label</div>,
            dataIndex: "intlLabel",
            key: "intlLabel",
            width: 131,
            className: `existing-rule-form-attributes ${highlightedFilters.intlLabel ? "highlighted-filter-icon" : ""}`,
            showSorterTooltip: { target: "full-header" },
            sorter: (a, b) => a.intlLabel.localeCompare(b.intlLabel),
            filterDropdown: () => renderFilterDropdownOther("intlLabel"),
        },
        {
            title: <div className="existing-rule-form-header">Entry Date</div>,
            dataIndex: "dateOfEntry",
            key: "dateOfEntry",
            width: 130,
            className: `existing-rule-form-attributes ${highlightedFilters.dateOfEntry ? "highlighted-filter-icon" : ""}`,
            fixed: 'right',
            sorter: (a, b) => new Date(a.dateOfEntry) - new Date(b.dateOfEntry),
            filterDropdown: () => renderFilterDropdownOther("dateOfEntry"),
        },
        {
            title: <div className="existing-rule-form-header"> </div>,
            key: "actions",
            fixed: 'right',
            width: 130,
            className: "existing-rule-form-attributes",
            render: (text, record) => (
                <span className="details-underline">
                    <ExistingRuleControlButtons.DetailsButton
                        selectedData={record} 
                    />
                </span>
            ),
        },
    ];
    


  

    const paginationConfig = PaginationConfig(filteredData,10);

    return (
        <Layout>
            <Content>
                <br />
                <div className="style-criteria-container">
                    <div className="recently-mapped-header">
                       
                        <span className="existing-rules-header-text">
                            {Constants.LABEL_EXISTING_RULES}
                        </span>
                        <div className="export-button-container">
                            <ExportResultsButton />
                        </div>
                    </div>
                    <span className="existing-rules-result-text">
                        {Constants.LABEL_EXISTING_RULES_TXT}
                    </span>
                    <Table
                        dataSource={filteredData}
                        columns={columns}
                        pagination={paginationConfig}
                        rowKey={(record) => record.key}
                        size="small"
                        className="custom-table-style"
                        scroll={{
                            x: 'max-content'
                        }}

                    />
                </div>
            </Content>
        </Layout>
    );
}
