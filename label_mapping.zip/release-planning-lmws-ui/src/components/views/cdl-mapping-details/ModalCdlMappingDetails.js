import React, { useState, useEffect } from "react";
import { Modal } from "antd";
import { InfoCircleOutlined, ExclamationCircleOutlined } from "@ant-design/icons";
import DomesticCdlHeader from "./components/DomesticCdlHeader";
import InternationalCdlHeader from "./components/InternationalCdlHeader";
import CdlMappingFooterButtons from "./components/CdlMappingFooterButtons";
import RulesEmployedEditDomesticCdlMappingDetails from "./components/RulesEmployedDomesticCdlMappingDetails";
import RulesEmployedEditInternationalCdlMappingDetails from "./components/RulesEmployedInternationalCdlMappingDetails";
import * as Constants from "../../util/constants";
import CustomCloseImageMappingCDL from "../../images/svg-components/CustomCloseImageMappingCDL";
import CustomVerificationCheckBoxImageMappingCDL from "../../images/svg-components/CustomVerificationCheckBoxImageMappingCDL";

const CDLMappingDetailsModal = ({ isVisible, onClose, selectedData = {} }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [showMessage, setShowMessage] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  // Current state for domestic fields
  const [domCountry, setDomCountry] = useState(selectedData.domCountry || "");
  const [domFamily, setDomFamily] = useState(selectedData.domFamily || "");
  const [domCompany, setDomCompany] = useState(selectedData.domCompany || "");
  const [domDivision, setDomDivision] = useState(selectedData.domDivision || "");
  const [domLabel, setDomLabel] = useState(selectedData.domLabel || "");

  // Current state for international fields
  const [intlCountry, setIntlCountry] = useState(selectedData.intlCountry || "");
  const [intlCompany, setIntlCompany] = useState(selectedData.intlCompany || "");
  const [intlDivision, setIntlDivision] = useState(selectedData.intlDivision || "");
  const [intlLabel, setIntlLabel] = useState(selectedData.intlLabel || "");

  // Saved state for domestic fields
  const [savedDataVauleOfDomCountry, setSavedDataVauleOfDomCountry] = useState(selectedData.domCountry || "");
  const [savedDataVauleOfDomFamily, setSavedDataVauleOfDomFamily] = useState(selectedData.domFamily || "");
  const [savedDataVauleOfDomCompany, setSavedDataVauleOfDomCompany] = useState(selectedData.domCompany || "");
  const [savedDataVauleOfDomDivision, setSavedDataVauleOfDomDivision] = useState(selectedData.domDivision || "");
  const [savedDataVauleOfDomLabel, setSavedDataVauleOfDomLabel] = useState(selectedData.domLabel || "");

  // Saved state for international fields
  const [savedDataVauleOfIntlCountry, setSavedDataVauleOfIntlCountry] = useState(selectedData.intlCountry || "");
  const [savedDataVauleOfIntlCompany, setSavedDataVauleOfIntlCompany] = useState(selectedData.intlCompany || "");
  const [savedDataVauleOfIntlDivision, setSavedDataVauleOfIntlDivision] = useState(selectedData.intlDivision || "");
  const [savedDataVauleOfIntlLabel, setSavedDataVauleOfIntlLabel] = useState(selectedData.intlLabel || "");

  const toggleEditMode = () => {
    setIsEditing(!isEditing);
    setShowMessage(false);
    setHasChanges(false);

    // Reset fields to saved state when toggling edit mode
    setDomCountry(savedDataVauleOfDomCountry);
    setDomFamily(savedDataVauleOfDomFamily);
    setDomCompany(savedDataVauleOfDomCompany);
    setDomDivision(savedDataVauleOfDomDivision);
    setDomLabel(savedDataVauleOfDomLabel);

    setIntlCountry(savedDataVauleOfIntlCountry);
    setIntlCompany(savedDataVauleOfIntlCompany);
    setIntlDivision(savedDataVauleOfIntlDivision);
    setIntlLabel(savedDataVauleOfIntlLabel);
  };

  const onSaveClick = () => {
    // Save current values into saved states
    setSavedDataVauleOfDomCountry(domCountry);
    setSavedDataVauleOfDomFamily(domFamily);
    setSavedDataVauleOfDomCompany(domCompany);
    setSavedDataVauleOfDomDivision(domDivision);
    setSavedDataVauleOfDomLabel(domLabel);

    setSavedDataVauleOfIntlCountry(intlCountry);
    setSavedDataVauleOfIntlCompany(intlCompany);
    setSavedDataVauleOfIntlDivision(intlDivision);
    setSavedDataVauleOfIntlLabel(intlLabel);

    setIsEditing(false);
    setShowMessage(true);
    setHasChanges(false);
  };

  const onCancelClick = () => {
    // Reset fields to last saved state
    setDomCountry(savedDataVauleOfDomCountry);
    setDomFamily(savedDataVauleOfDomFamily);
    setDomCompany(savedDataVauleOfDomCompany);
    setDomDivision(savedDataVauleOfDomDivision);
    setDomLabel(savedDataVauleOfDomLabel);
  
    setIntlCountry(savedDataVauleOfIntlCountry);
    setIntlCompany(savedDataVauleOfIntlCompany);
    setIntlDivision(savedDataVauleOfIntlDivision);
    setIntlLabel(savedDataVauleOfIntlLabel);
  
    // Exit edit mode
    setIsEditing(false);
  
    // Reset any UI flags for messaging
    setShowMessage(false);
    setHasChanges(false);
  };
  

  const checkForChanges = () => {
    const isDomesticChanged =
      savedDataVauleOfDomCountry !== domCountry ||
      savedDataVauleOfDomFamily !== domFamily ||
      savedDataVauleOfDomCompany !== domCompany ||
      savedDataVauleOfDomDivision !== domDivision ||
      savedDataVauleOfDomLabel !== domLabel;

    const isInternationalChanged =
      savedDataVauleOfIntlCountry !== intlCountry ||
      savedDataVauleOfIntlCompany !== intlCompany ||
      savedDataVauleOfIntlDivision !== intlDivision ||
      savedDataVauleOfIntlLabel !== intlLabel;

    setHasChanges(isDomesticChanged || isInternationalChanged);
  };

  useEffect(() => {
    if (isEditing) {
      checkForChanges();
    }
  }, [domCountry, domFamily, domCompany, domDivision, domLabel, intlCountry, intlCompany, intlDivision, intlLabel]);

  return (
    <Modal
      title={
        <div>
          {showMessage && (
            <div className="modal-save-success-message-container">
              <table className="modal-save-success-message-table">
                <tr>
                  <td align="center">
                    <span>
                      <CustomVerificationCheckBoxImageMappingCDL />
                      <span className="rule-create-success">
                        {Constants.RULE_CREATE_SUCCESS}
                      </span>
                    </span>
                  </td>
                  <td align="right">
                    <span>
                      <CustomCloseImageMappingCDL onClick={() => setShowMessage(false)} />
                    </span>
                  </td>
                </tr>
              </table>
            </div>
          )}
          <span className="modal-title">
            {isEditing ? (
              <ExclamationCircleOutlined className="exclamation-editmode-outline" />
            ) : (
              <InfoCircleOutlined className="exclamation-viewmode-outline" />
            )}
            {isEditing ? (
              <div className="editMode">
                {Constants.LABEL_EDIT_CDL_MAPPING_DETAILS}
              </div>
            ) : (
              <div className="viewMode">
                <label className="view-CDL-label">
                  {Constants.LABEL_VIEW_CDL_MAPPING_DETAILS}
                </label>
              </div>
            )}
          </span>
        </div>
      }
      visible={isVisible}
      onCancel={onClose}
      footer={
        !isEditing ? (
          <CdlMappingFooterButtons
            onClose={onClose}
            onEdit={toggleEditMode}
            onCancel={onCancelClick}
            onSave={onSaveClick}
            isEditing={isEditing}
            isSaveDisabled={!hasChanges}
          />
        ) : null
      }
      closeIcon={null}
    >
     {isEditing ? <div className="edit-cdl-label">{Constants.LABEL_EDIT_CDL_TEXT}</div> : ""}
      <DomesticCdlHeader
        domCountry={domCountry}
        domFamily={domFamily}
        domCompany={domCompany}
        domDivision={domDivision}
        domLabel={domLabel}
        originalDomCountry={selectedData.domCountry}
        originalDomFamily={selectedData.domFamily}
        originalDomCompany={selectedData.domCompany}
        originalDomDivision={selectedData.domDivision}
        originalDomLabel={selectedData.domLabel}
      />

      <div className="maps-to-text">{Constants.LABEL_MAPS_TO}</div>
      <InternationalCdlHeader
        intlCountry={intlCountry}
        intlCompany={intlCompany}
        intlDivision={intlDivision}
        intlLabel={intlLabel}
        originalIntlCountry={selectedData.intlCountry}
        originalIntlCompany={selectedData.intlCompany}
        originalIntlDivision={selectedData.intlDivision}
        originalIntlLabel={selectedData.intlLabel}
      />
      <br />
      <section
        className={`rules-employed-container ${
          isEditing ? "editing-mode" : "view-mode"
        }`}
      >
        {isEditing ? (
          <div className="editMode">
            <div className="rule-employed-header">
              <ExclamationCircleOutlined className="exclamation-redcolor-outline" />
              <span className="editing-warning-text">
                {Constants.LABEL_EDIT_CDL_TEXT_V2}
              </span>
            </div>
          </div>
        ) : (
          <div className="viewMode">
            <div className="rule-employed-header">
              {Constants.LABEL_RULE_EMPLOYED_TXT}
            </div>
          </div>
        )}
        <RulesEmployedEditDomesticCdlMappingDetails
          isEditing={isEditing}
          domCountry={domCountry}
          domFamily={domFamily}
          domCompany={domCompany}
          domDivision={domDivision}
          domLabel={domLabel}
          setDomCountry={setDomCountry}
          setDomFamily={setDomFamily}
          setDomCompany={setDomCompany}
          setDomDivision={setDomDivision}
          setDomLabel={setDomLabel}
        />
        <div className="maps-to-text-inside-edit-section">{Constants.LABEL_MAPS_TO}</div>
        <RulesEmployedEditInternationalCdlMappingDetails
          isEditing={isEditing}
          intlCountry={intlCountry}
          intlCompany={intlCompany}
          intlDivision={intlDivision}
          intlLabel={intlLabel}
          setIntlCountry={setIntlCountry}
          setIntlCompany={setIntlCompany}
          setIntlDivision={setIntlDivision}
          setIntlLabel={setIntlLabel}
        />
        {isEditing ? (
          <div>
            <CdlMappingFooterButtons
              onClose={onClose}
              onEdit={toggleEditMode}
              onCancel={onCancelClick}
              onSave={onSaveClick}
              isEditing={isEditing}
              isSaveDisabled={!hasChanges}
            />
          </div>
        ) : ""}
      </section>
    </Modal>
  );
};

export default CDLMappingDetailsModal;
