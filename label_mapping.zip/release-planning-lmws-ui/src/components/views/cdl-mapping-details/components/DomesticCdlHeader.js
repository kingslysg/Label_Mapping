import React from "react";
import * as Constants from "../../../util/constants";

const DomesticCdlHeader = ({ 
    domCountry, 
    domFamily, 
    domCompany, 
    domDivision, 
    domLabel, 
    originalDomCountry, 
    originalDomFamily, 
    originalDomCompany, 
    originalDomDivision, 
    originalDomLabel 
}) => (
    <div>
        <h3 className="view-cdl-header">{Constants.LABEL_DOMESTIC_CDL}</h3> 
        <div className="domestic-cdl-container">
            <div className="section-content">
                <div className="detail-item">
                    <span className="domestic-cdl-header-label">{Constants.COUNTRY}:</span> 
                    <span className="domestic-cdl-value-label">{originalDomCountry}</span>
                </div>
                <div className="detail-item">
                    <span className="domestic-cdl-header-label">{Constants.FAMILY}:</span>
                    <span className="domestic-cdl-value-label">{originalDomFamily}</span>
                </div>
                <div className="detail-item">
                    <span className="domestic-cdl-header-label">{Constants.COMPANY}:</span>
                    <span className="domestic-cdl-value-label">{originalDomCompany}</span>
                </div>
                <div className="detail-item">
                    <span className="domestic-cdl-header-label">{Constants.DIVISION}:</span>
                    <span className="domestic-cdl-value-label">{originalDomDivision}</span>
                </div>
                <div className="detail-item">
                    <span className="domestic-cdl-header-label">{Constants.LABEL}:</span>
                    <span className="domestic-cdl-value-label">{originalDomLabel}</span>
                </div>
            </div>
        </div>
    </div>
);

export default DomesticCdlHeader;
