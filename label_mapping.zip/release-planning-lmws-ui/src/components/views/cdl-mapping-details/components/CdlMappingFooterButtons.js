import React from "react";
import { Button } from "antd";
import * as Constants from "../../../../components/util/constants";


const CloseButton = ({ onClose }) => (
    <Button onClick={onClose} className='defaultButtonStyle'>
        {Constants.BUTTON_CLOSE}
    </Button>
);

const CancelButton = ({ onCancel }) => (
    <Button onClick={onCancel} className='defaultButtonStyle'>
        {Constants.BUTTON_CANCEL}
    </Button>
);

const EditButton = ({ onEdit }) => (
    <Button type="primary" onClick={onEdit} className='selectedButtonStyle'>
        {Constants.BUTTON_EDIT}
    </Button>
);

const SaveButton = ({ onSave, disabled }) => (
    <Button 
        type="primary" 
        onClick={onSave} 
        className='selectedButtonStyle'
        disabled={disabled}
    >
        {Constants.BUTTON_SAVE}
    </Button>
);


const CdlMappingFooterButtons = ({ onClose, onEdit, onCancel, onSave, isEditing, isSaveDisabled }) => (
    <div className="footer-buttons">
        {!isEditing && (
            <div className="viewMode">
        <CloseButton onClose={onClose} />&nbsp;&nbsp;
        <EditButton onEdit={onEdit} />
            </div>
        )}

        {isEditing && (
            <div className="editMode">
                <CancelButton onCancel={onCancel} />&nbsp;&nbsp;
                <SaveButton onSave={onSave} disabled={isSaveDisabled}/>
            </div>
        )}
    </div>
);

export default CdlMappingFooterButtons;
