import React from "react";
import * as Constants from "../../../util/constants"

const InternationalCdlHeader = ({
    intlCountry,
    intlCompany,
    intlDivision,
    intlLabel,
    originalIntlCountry,
    originalIntlCompany,
    originalIntlDivision,
    originalIntlLabel,
}) => (
    <div>
        <h3 className="view-cdl-header">{Constants.LABEL_INTERNATIONAL_CDL}</h3>
        <div className="international-cdl-container">
            <div className="section-content">
                <div className="detail-item">
                    <span className="international-cdl-header-label">{Constants.COUNTRY}:</span>
                    <span className="international-cdl-value-label">
                        {originalIntlCountry}
                    </span>
                </div>
                <div className="detail-item">
                    <span className="international-cdl-header-label">{Constants.COMPANY}:</span>
                    <span className="international-cdl-value-label">{originalIntlCompany}</span>
                </div>
                <div className="detail-item">
                    <span className="international-cdl-header-label">{Constants.DIVISION}:</span>
                    <span className="international-cdl-value-label">{originalIntlDivision}</span>
                </div>
                <div className="detail-item">
                    <span className="international-cdl-header-label">{Constants.LABEL}:</span>
                    <span className="international-cdl-value-label">{originalIntlLabel}</span>
                </div>
            </div>
        </div>
    </div>
);

export default InternationalCdlHeader;
