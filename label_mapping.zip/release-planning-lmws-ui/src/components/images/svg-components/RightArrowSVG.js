// SmallSVG.jsx
import React from 'react';

const RightArrowSVG = ({ x, y }) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none" x={x} y={y}>
      <path d="M2.3999 1.35015V2.28765C2.3999 2.3514 2.43115 2.4114 2.4824 2.4489L7.3774 6.00015L2.4824 9.5514C2.43115 9.5889 2.3999 9.6489 2.3999 9.71265V10.6501C2.3999 10.7314 2.4924 10.7789 2.55865 10.7314L8.6349 6.3239C8.8549 6.1639 8.8549 5.8364 8.6349 5.67765L2.55865 1.27015C2.4924 1.2214 2.3999 1.2689 2.3999 1.35015Z" fill="black" fillOpacity="0.45" />
    </svg>
  );
};

export default RightArrowSVG;
