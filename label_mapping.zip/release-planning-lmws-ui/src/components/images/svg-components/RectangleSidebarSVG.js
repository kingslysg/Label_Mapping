// LargeSVG.jsx
import React from 'react';

import RightArrowSvgImage from './RightArrowSVG';

const RectangleSidebarSVG = ({ collapsed }) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="66" viewBox="0 0 12 66" fill="none">
      <path d="M0 0L12 8V58L0 66V0Z" fill="white" />
       <RightArrowSvgImage x="0" y="30" />
    </svg>
  );
};

export default RectangleSidebarSVG;
