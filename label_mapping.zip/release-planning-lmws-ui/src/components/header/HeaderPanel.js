import React, { useState } from 'react';
import {
  DesktopOutlined,
  FileOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
  BellOutlined   
} from '@ant-design/icons';
import { Breadcrumb, Layout, Menu, Row, theme, Badge } from 'antd';
import Logo from '../images/lmws_header_banner.png';

export default function HeaderPanel() {

  const { Header } = Layout;
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  // State to manage notification count
  const [notificationCount, setNotificationCount] = useState(5); //5 notifications

  return (
    <div>
      <Header
        style={{
          padding: 0,
          background: colorBgContainer,
        }}
      >
        <div className="header-content">   
          {/* Left section: Logo and Text */}
          <div className="logo-container">
            <img className="logo-image-position" src={Logo} alt="Logo" />
            <span className="logo-text">LMWS</span>
          </div>

          {/* Right section: User icon and Notification bell */}
          <div className="icon-container">
            {/* User icon */}
            <UserOutlined className="login-avatar" />
            {/* Notification bell */}
            <Badge count={notificationCount} overflowCount={99} offset={[-13,0]} className="notification-badge">
              <BellOutlined className="notification-bell" />
            </Badge>
          </div>
        </div>
      </Header>
    </div>
  );
}
