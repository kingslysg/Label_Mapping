import React from "react";

const PaginationConfig = (filteredData) => ({
    pageSize: 5,
    disabled: filteredData.length <= 5,
    showSizeChanger: false,
});

export default PaginationConfig;