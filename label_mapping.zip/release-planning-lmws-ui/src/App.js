import React, { useEffect, useState } from 'react';
import { ConfigProvider, Layout, theme } from "antd";
import LmwsNavigationPanel from './components/layout/LmwsNavigationPanel';


const darkToken = {
  fontFamily: "Roboto Condensed",
  colorPrimary: "#0288D1",
  borderRadius: 2,
  colorContent: '#000',
  colorDarkGrey: "#212121",
  tableHeaderBg: '#000',
  tableBodyBg: '#000',
  colorText: "#fff",
  colorInfo: "#0288D1",
  colorDark: "#000",
  colorBgHeader: "#222222",
  colorItemBg: "#333333",
  colorListItem: "#191919",
  headerText: "#fff",
  colorSecondary: "#85D305",
  colorBgContainer: "#001529",

};

const defaultToken = {
  fontFamily: "Roboto Condensed",
  colorPrimary: "#85D305",
  borderRadius: 2,
  colorText: "#000",
  colorInfo: "#0288D1",
  colorWhite: "#ffffff",
  colorIcon: "#212121",
  colorDark: "#000",
  colorBgHeader: "#E9E9E9",
  colorDarkGrey: "#D9D9D9",
  colorItemBg: "#ddd",
  colorListItem: "#191919",
  headerText: "#fff",
  colorSecondary: "#50C1FF",
  colorBgContainer: "#D9D9D9",
  colorContent: '#fff',
  tableHeaderBg: '#fff',
  tableBodyBg: '#fff',
  headerColor: '#DEE3EB',


};

const App = () => {

const[loaded,setLoaded]=useState(false);
const consoleWarn = console.warn;
const SUPPRESSED_WARNINGS = ['Script error'];




function loadError(onError) {
  console.error(`Failed ${onError.target.src} didn't load correctly`);
}



  
 useEffect(() => {
    const LoadExternalScript = () => {
      /*
      */ 
      
    };
    LoadExternalScript();
  }, []);

    useEffect(() => {
   
    if(!loaded) return;

  }, [loaded])

  const isDarkToken = false

  let selectedToken = defaultToken
  if (isDarkToken) {
    selectedToken = darkToken
  }
  return (
    <Layout>
        <LmwsNavigationPanel />
    </Layout>
  );
};

export default App; 
