import React from 'react';
import ReactDOM from 'react-dom/client';
import '../src/components/stylesheet/lmws.css';
import App from './App';
import 'antd/dist/reset.css'
import '../src/components/stylesheet/ant-override.css';
import reportWebVitals from './reportWebVitals';
import { Layout } from 'antd';
import '../src/components/stylesheet/searchMappings.css';
import '../src/components/stylesheet/recentlyMappedCDL.css';
import '../src/components/stylesheet/cdlMappingDetails.css';
import '../src/components/stylesheet/unmappedCDL.css';

import { PublicClientApplication, EventType } from '@azure/msal-browser';
import { msalConfig } from './msalConfig';
import '../src/components/stylesheet/searchMappings.css';
import '../src/components/stylesheet/recentlyMappedCDL.css';
import '../src/components/stylesheet/cdlMappingDetails.css';
import '../src/components/stylesheet/unmappedCDL.css';
import '../src/components/stylesheet/createRule.css'


/**
 * MSAL should be instantiated outside of the component tree to prevent it from being re-instantiated on re-renders.
 */
const msalInstance = new PublicClientApplication(msalConfig)
msalInstance.initialize().then(() => {
   // Default to using the first account if no account is active on page load
  if (!msalInstance.getActiveAccount() && msalInstance.getAllAccounts().length > 0) {
        // Account selection logic is app dependent. Adjust as needed for different use cases.
        msalInstance.setActiveAccount(msalInstance.getAllAccounts()[0])
  }

  msalInstance.enableAccountStorageEvents()

  msalInstance.addEventCallback(event => {
    if (event.eventType === EventType.LOGIN_SUCCESS ||
      event.eventType === EventType.ACQUIRE_TOKEN_SUCCESS ||
      event.eventType === EventType.SSO_SILENT_SUCCESS) {
      const account = event.payload.account
      msalInstance.setActiveAccount(account)
    }
  })
})
  .catch(err => {
    console.error('Error during initialization');
    console.error(err);
  })

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Layout>
    <React.StrictMode>
      <App instance={msalInstance} />
    </React.StrictMode>
  </Layout>
);


reportWebVitals();
